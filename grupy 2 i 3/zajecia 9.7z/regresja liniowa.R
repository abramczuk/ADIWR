 

## Rysowanie linii regresji

#Dostrzeżenie niezbyt silnych związków na wykresie obrazującym dużą liczbę danych mimo wszystko może być trudne. W takim przypadku wskazane może być naniesienie na wykres **linii/krzywej regresji**. W znacznym uproszczeniu jest to linia/krzywa, której nachylenie/przebieg dobrane zostało w taki sposób, aby minimalizować *błąd przewidywania* wartości zmiennej prezentowanej na osi Y przy pomocy wartości zmiennej prezentowanej na osi X. 

#Na dzisiejszych zajęciach zajmiemy się jednymi z najbardziej podstawowych i najbardziej popularnych narzędzi analizy zależności między zmiennymi ilościowymi, czyli współczynnikiem korelacji i regresją liniową.

#Uwaga: przykłady zawarte w tym materiale nie stanowią wprowadzenia do tematu regresji. Warto sięgnąć do dodatkowych zasobów. Każdy podręcznik do statystyki zawiera jakieś wprowadzenie do tego tematu. Poza klasycznymi podręcznikami można sięgnąć po zasoby online, np.

#1. [serię wykładów z ćwieczeniami](https://www.khanacademy.org/math/statistics-probability/describing-relationships-quantitative-data) dotyczących analiz dwuzmiennowych na khan academy, w szczególności:

#1.1. materiały o [regresji najmniejszych kwadratów](https://www.khanacademy.org/math/statistics-probability/describing-relationships-quantitative-data/regression-library/v/introduction-to-residuals-and-least-squares-regression)

#1.2 materiały o [ocenie jakości dopasowania](https://www.khanacademy.org/math/statistics-probability/describing-relationships-quantitative-data/assessing-the-fit-in-least-squares-regression/v/residual-plots) 

#1.3 materiały o [matematyce w tle](https://www.khanacademy.org/math/statistics-probability/describing-relationships-quantitative-data/more-on-regression/v/squared-error-of-regression-line) 

#2. encyklopedyczne [podsumowanie tematu regresji i jej założeń](https://www.statsoft.pl/textbook/stathome_stat.html?https%3A%2F%2Fwww.statsoft.pl%2Ftextbook%2Fstmulreg.html)

#Zmienne mierzone na skalach mocnych często przyjmują bardzo dużo wartości, co czyni takie tabele i wykresy nieczytelnymi. Możemy wówczas pokategoryzować wartości (co można zrobić przy użyciu poznanej przez nas funkcji recode) i zamienić zmienną mocną np na porządkową. Możemy też obliczyć jakieś parametry rozkładu (np. średnią). 

#Kiedy analizujemy, w jaki sposób wartości zmiennej mierzonej na skali mocnej zmieniają się dla kategorii wyróznionych ze względu na wartość zmiennej mierzonej na skali słabej, często obliczamy zatem średnie warunkowe albo robimy serie wykresów rozkładów w podgrupach (np wykresy skrzypcowe albo pudełkowe). Kiedy analizujemy zależności między dwiema lub większą liczbą zmiennych mierzonych na skali mocnej, możemy też zastosować bardziej złożone techniki analizy, z których najprostszą jest analiza regresji liniowej najmniejszych kwadratów.

#Na marginesie odnotujmy, że co do zasady **tylko** zmienne mierzone na **skalach mocnych** mogą być używane w prostej analizie regresji. Istnieją jednak techniki, których tu na razie nie omawiamy, a które umożliwiają użycie w regresji także zmiennych mierzonych na skalach słabych.


#Pakiet *ggplot2* umożliwia dodanie takiej linii/krzywej w bardzo prosty sposób – przy pomocy *geometrii* `geom_smooth()`. W wywołaniu funkcji `aes()` musimy przypisać zmienne do osi X i Y – jeśli dodajemy linię regresji do wykresu rozrzutu, to w obu geometriach powinny to być oczywiście te same zmienne. Domyślnie wykreślana jest krzywa (wykorzystywana jest do tego tzw. regresja nieparametryczna).

#- Jeśli chcemy uzyskać linię prostą, należy w wywołaniu `geom_smooth()` podać dodatkowy argument `method = "lm"` (aby zastosować regresję liniową).
#- Jeśli zmienna prezentowana na osi X przyjmuje bardzo niewiele różnych wartości (jak w przykładzie poniżej), regresja nieparametryczna może nie dać się obliczyć i konieczne będzie użycie regresji liniowej.
#- Użycie argumentu `se = FALSE` sprawia, że wokół linii/krzywej nie będzie rysowany obszar ufności dla przewidywania.

#Wykres obrazujący związek pomiędzy liczbą lat nauki rodzica a liczbą osób w gospodarstwie domowym ucznia z naniesioną linią regresji liniowej wygląda tak:

ggplot(pisa) +
  geom_count(aes(x = parEdu,
                 y = noPersHous)) +
  geom_smooth(aes(x = parEdu,
                  y = noPersHous),
              method = "lm")

ggplot(pisa) +
  geom_count(aes(x = parEdu,
                 y = noPersHous)) +
  geom_smooth(aes(x = parEdu,
                  y = noPersHous),
              method = "lm", se = FALSE)


#Teraz wyraźnie widać, że mamy do czynienia ze związkiem o charakterze negatywnym (statystycznie więcej lat nauki rodziców współwystępuje z mniejszą liczbą członków gospodarstwa domowego), choć nie jest on bardzo silny.

#Linie regresji możemy też narysować oddzielnie dla różnych grup, jeśli w wywołaniu `aes()` podamy zmienną grupującą argumentem `color` lub `linetype`. Argumentem `size` można z kolei zmieniać grubość linii/krzywej.

#Np. wykres rozrzutu obrazujący związek pomiędzy wskaźnikiem statusu społeczno-ekonomicznego rodziców (`hisei`) a wynikami testu PISA w zakresie matematyki w szkołach różnych typów można uzyskać tak:

ggplot(pisa) +
  geom_point(aes(x = hisei, y = scorePISAMath,
                 color = schoolType)) +
  geom_smooth(aes(x = hisei, y = scorePISAMath,
                  color = schoolType),
              size = 1.5,
              se = FALSE)

#Jeśli, jak na wykresie powyżej, zbyt duża liczba obserwacji sprawia, że wykres staje się nieczytelny, można ograniczyć się do narysowania samych krzywych/linii regresji:

ggplot(pisa) +
  geom_smooth(aes(x = hisei, y = scorePISARead,
                  color = schoolType),
              size = 1.5,
              se = FALSE)

ggplot(pisa) +
  geom_smooth(aes(x = hisei, y = scorePISARead,
                  color = schoolType),
              size = 1.5)

# Równanie regresji

## Rysowanie prostej regresji

#Zaczniemy od przykładu z matematyką i czytaniem. 

#Narysowaliśmy już wykres rozrzutu przedstawiający zależność między wynikiem testu z matematyki a wynikiem testu z czytania.

ggplot(pisa) +
  geom_point(aes(x = scorePISAMath, y = scorePISARead)) 

#Wyniki obu testów mierzone są na skalach mocnych. Możemy zatem wyznaczyć regresję wyniku testu z czytania w zależności o wyniku testu z matematyki. Regresja taka będzie opisywała matematycznie intuicję, która mówi, że wyższe wyniki z matematyki związane są, ogólnie rzecz biorąc, z wyższymi wynikami w teście z czytania. Ściśle rzecz biorąc powiemy wówczas, że dla uczniów z wyższym wynikiem z matematyki przewidywać będziemy wyższy wynik testu z czytania. Nasz przewidywany wynik testu z czytania wyrazimy jako funkcję liniową wyniku z matematyki. Wykres tej funkcji liniowej umiemy już dodać do naszego wykresu posługując się opcją method = "lm", gdzie lm oznacza "linear model" czyli "model liniowy":

ggplot(pisa) +
  geom_point(aes(x = scorePISAMath, y = scorePISARead)) +
  geom_smooth(aes(x = scorePISAMath,
                  y = scorePISARead),
              method = "lm", se = FALSE)

#Ten sam efekt możemy uzyskać przy pomocy krótszego zapisu, gdzie osie (wspólne dla wykresu punktowego i liniowego) opisane są w wywołaniu samego ggplot:

ggplot(pisa, aes(scorePISAMath, scorePISARead)) +
  geom_point() +
  geom_smooth(method = "lm")

#Możemy też narysować samą regresję:

ggplot(pisa, aes(scorePISAMath, scorePISARead)) +
  geom_smooth(method = "lm")

## Wyznaczanie równania regresji

#Zauważmy, że w obu przypadkach R wyświetla nam komunikat: 

#  > `geom_smooth()` using formula 'y ~ x'

#Zapis ten oznacza, że linia, która została narysowana, może być matematycznie opisana przy pomocy wzoru:

#  > y = a + b*x

#gdzie:

#  **y** to zmienna zależna, której wartość chcemy przewidywać (w naszym przypadku wynik testu z czytania)

#**x** to zmienna niezależna, której wartośc służy przewidywaniu wartości zmiennej zależnej (w naszym przypadku wynik testu z matematyki)

#**a** to współczynnik przesunięcia prostej będącej naszym przewidywaniem

#**b** to współczynnik kierunkowy prostej będącej naszym przewidywaniem 

#Zatem linia, którą narysowaliśmy może być opisana wzorem:

# scorePISARead = a + b*scorePISAMath

#Współczynniki *a* i *b* są dobierane w taki sposób, aby zminimalizować średni kwadrat błędu przewidywania. Za chwilę zobaczymy, co to oznacza. Najpierw zobaczmy, ile wynoszą *a* i *b* w naszym przypadku. Służy do tego funkcja lm, będąca częścią bazowego R, Można ją wywołać niezależnie od wykresu, a wyniki przechować w nowym obiekcie, który nazwiemy "regresja":

regresja <- lm(scorePISARead ~ scorePISAMath, pisa)
regresja

#Współczynnik przesunięcia naszej regresji (tzw. Intercept czyli **a** z równania wyżej) wynosi *111.435*. Interpretujemy go, jako przewidywaną wartość zmiennej zależnej dla obserwacji, dla której wartość zmiennej niezależnej wynosi zero. Zatem w naszym przypadku dla osoby, która uzyskała zero punktów z testu z matematyki, przewidywany wynik testu z czytania to 111.435 punkta.

#Współczynnik nachylenia naszej regresji to *0.789* (czyli **b**). Interpretujemy, go jako różnicę wartości przewidywanej zmiennej zależnej dla dwóch obiektów, które różnią się wartością zmiennej niezależnej o jeden. Zatem w naszym przypadku, jeśli weźmiemy dwóch uczniów, z których pierwszy ma wynik testu z matematyki o 1 punkt wyższy niż drugi, to przewidywany wynik testu z czytania dla ucznia pierwszego będzie o 0.789 punkta wyższy niż dla drugiego.

# scorePISARead = 111.435 + 0.789*scorePISAMath 

#Znając te współczynnki oraz wyniki testu z matematyki możemy wyznaczyć przewidywaną wartość wyniku testu z czytania, dla każdego ucznia w naszym zbiorze. Moglibyśmy zrobić to "na piechotę", ale możemy też użyć do tego funkcji *predict*. 

pisa <- pisa %>% mutate(Readrecznie = 0.789*scorePISAMath + 111.435,
                        Readauto = predict(regresja))
pisa %>% select(Readrecznie, Readauto) %>% head()

#Różnice w wartościach między tymi dwiema kolumnami wynikają z tego, że funkcja predict używa współczynników regresji wyznaczonych z większą dokładnością niż trzy miejsca po przecinku. 

#Teraz dla każdego obiektu możemy wyznaczyć błąd przewidywania, nazywany także resztą lub rezyduum. Błąd przewidywania to różnica między rzeczywistą wartością zmiennej dla danego obiektu a wartością dla niego przewidywaną (użyjemy wartości dokładniejszych):

pisa <- pisa %>% mutate(Readreszta = scorePISARead - Readauto)
pisa %>% select(scorePISARead, scorePISAMath, Readauto, Readreszta) %>% head()

#Przyjrzyjmy się pierwszemu wierszowi w tej tabeli. Uczeń opisany w tym wierszu uzyskał z matematyki wynik 611.4486 punkta. Przewidywany wynik testu z czytania wyniósł zatem dla niego: 0.789*611.4486 + 111.435 = 593.8406, podczas gdy jego rzeczywisty wynik z czytania był niższy o 71.724951 punkta i wynosił 522.1156.

#Jak widać reszty mogą być zarówno dodatnie jak i ujemne. Jednak dla oceny regresji znak reszty nie ma znaczenia. Równanie regresji jest wyznaczane przy pomocy narzędzi analizy matematycznej w taki sposób, aby średni kwadrat błędu przewidywania był jak najmniejszy. Możemy obliczyć ile wynosi średni kwadrat błedu przewidywania w naszym przypadku:

mean(pisa$Readreszta^2) 

#Dość łatwo można wykazać, że nie istnieją *a* i *b* inne niż te wyznaczone, dla których średni kwadrat błędu przewidywania byłby mniejszy niż 2326.12.

## Ocena dopasowania modelu

#Wartości reszt mówią nam o tym, jak dobre, a właściwie jak złe, jest nasze przewidywanie. Zasadniczo im większe są wartości bezwzględne reszt, tym przewidywanie przy pomocy regresji liniowej jest gorsze, albo też model liniowy słabiej opisuje obserwowaną zależność. Dlatego warto przyjrzeć się resztom bliżej. Można to zrobić "na piechotę":

summary(pisa$Readreszta)
mean(pisa$Readreszta)
sd(pisa$Readreszta)
var(pisa$Readreszta)

#Zwróć uwagę, że średnia reszt jest praktycznie równa zero. Musi tak być, gdyż w przeciwnym wypadku przewidywanie nie byłoby optymalne. Im natomiast większe będzie odchylenie standardowe reszt tym model będzie (przy stałej wariancji zmiennej zależnej) gorzej dopasowany.

#Można też siegnąć do statystyk wyznaczanych automatycznie przez fukcję *lm*. Listę wszystkich statystyk wyznaczanych przez tę funkcję można uzyskać przy pomocy polecenia *attributes*. Dostęp do każdego z atrybutów można uzyskać oddzielnie na rózne sposoby:

attributes(regresja)
#współczynniki regresji
coef(regresja)
#albo
regresja$coef
#statystyki reszt
summary(resid(regresja))
#albo
summary(regresja$resid)

#Możemy też wyświetlić całościowe podsumowanie dla naszej regresji:

summary(regresja)

#Output ten ma następującą strukturę:

#1. wywołanie z formułą regresji (tu widać, która zmienna jest zależną, a która jest niezależną)

#2. statystyki reszt

#3. współczynniki regresji wraz z dodatkowymi statystykami przydatnymi wtedy, gdy chcemy wnioskować o populacji na podstawie próby

#4. Informacja o odchyleniu standardowym reszt (zwróć uwagę, że to ta sama wartość, którą wyznaczyliśmy wcześniej przy pomocy wywołania *sd(pisa$Readreszta)*)

#5. Współczynnik R kwadrat i skorygowany współczynnik R kwadrat (przydatny wtedy, gdy oceniamy dopasowanie bardzo złożonych modeli regresji)

#6. Statystyka F dla hipotezy zerowej, że zmienna zależna nie jest liniowo związana ze zmiennymi niezależnymi. Jest przydatna wtedy, gdy chcemy wnioskować o populacji na podstawie próby

#Zostawmy na razie wnioskowanie o populacji na podstawie próby. Przyjrzymy się jednak wartości współczynnika R kwadrat, który jest ogólną miarą jakości dopasowania modelu liniowego do danych. Współczynnik ten przyjmuje wartości między 0 a 1, gdzie zero oznacza, że model liniowy zupełnie nie pasuje do danych a jeden oznacza, że model linowy opisuje dane idealnie. Konkretnie wartość ta jest ilorazem:

1-var(pisa$Readreszta)/var(pisa$scorePISARead)
#albo (co jest tym samym)
(var(pisa$scorePISARead)-var(pisa$Readreszta))/var(pisa$scorePISARead)

#Jeśli w naszej regresji są tylko dwie zmienne, współczynnik R kwadrat jest tym samym, co współczynnik korelacji liniowej Pearsona (powszechnie znany po prostu jako *korelacja*) podniesiony do kwadratu. Wspólczynnik ten można wyznaczyć także przy pomocy funkcji *cor*.

pisa %>% summarise(cor(scorePISAMath,scorePISARead)^2)

#Jeśli wariancja reszt jest taka sama jak wariancja zmiennej przewidywanej, współczynnik R kwadrat wynosi zero, co oznacza, że przewidywanie przy pomocy regresji nie jest lepsze od przewidywania wartości zmiennej zależnej przy pomocy jej średniej.

#Jeśli wariancja reszt wynosi zero, współczynnik R kwadrat wynosi jeden, co oznacza, że wszystkie przewidywania są takie same jak wartości rzeczywiste zmiennej zależnej, czyli przewidywanie jest doskonałe

# Założenie o liniowości zależności

#Najbardziej podstawowym założeniem regresji liniowej jest założenie o tym, że zależność między zmiennymi ma charakter liniowy. W omawianym dotychczas przykładzie założenie to wydaje się być spełnione. Kiedy popatrzymy na wykres, zobaczymy, że punkty oznaczające poszczególne obserwacje układają się wzdłuż linii regresji:

ggplot(pisa, aes(scorePISAMath, scorePISARead)) +
  geom_point() +
  geom_smooth(method = "lm")

#Nie zawsze tak jest. Przyjrzymy się teraz kilku możliwym przypadkom. 

## Brak zależności liniowej

#Rozpatrywaliśmy już przykład obrazujący związek pomiędzy wskaźnikiem statusu społeczno-ekonomicznego rodziców (`hisei`) a wynikami testu PISA w zakresie matematyki w szkołach różnych typów:

ggplot(pisa) +
  geom_smooth(aes(x = hisei, y = scorePISARead,
                  color = schoolType),
              size = 1.5,
              se = FALSE)

#Przyjrzymy się teraz regresji liniowej wyniku testu z czytania względem statusu w Liceach Profilowanych:

pisaLP <- pisa %>% filter(schoolType == "LP")

pisaLP %>%
  ggplot(aes(hisei, scorePISARead)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

#Co prawda regresja została wyznaczona, ale widzimy że obserwacje nie układają się wzdłuż wyznaczonej prostej, a sama prosta jest dość bliska funkcji stałej, co wskazuje na brak lub bardzo słabą zależność liniową. Możemy się co do tego upewnić wyznaczając równanie regresji i miary jej dopasowania:


pisaLP %>% lm(formula = scorePISARead ~ hisei) %>% summary

#Widzimy, że współczynnik nachylenia regresji jest dość mały, a R kwadrat jest bliskie zera. Możemy zatem powiedzieć, że wynik testu z czytania nie jest liniowo związany ze statusem wśród uczniów liceów profilowanych.


## Idealna zależność liniowa

#Na drugim biegunie możemy rozpatrzeć sytuację, gdy zależność jest doskonała. W tym celu stworzymy sobie nową zmienną, która będzie funkcją liniową wyniku testu z czytania i zobaczymy, co się stanie, gdy wstawimy ją do funkcji regresji.


pisa <- pisa %>% mutate(eksperyment = 2*scorePISARead + 3)
regresja3 <- lm(scorePISARead ~ eksperyment, pisa)
summary(regresja3) 

#Teraz R kwadrat wynosi jeden a funkcja regresji jest funkcją odwrotną do tej, przy pomocy której stworzyliśmy zmienną eksperyment. Żeby to lepiej zobaczyć możemy wyświetlić współczynniki regresji z pominięciem notacji naukowej:

format(coef(regresja3), scietific = F) 

## Obserwacje odstające

#Równanie regresji jest bardzo wrażliwe na istnienie obserwacji odstających, czyli takich, które wyraźnie nie pasują do wzoru zależności. Spójrzmy na zależność wyniku testu z czytania od wyniku testu z matematyki w zbiorowości uczniów Liceów Profilowanych:

pisaLP %>%
  ggplot(aes(scorePISAMath, scorePISARead)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  geom_text(aes(label=id),hjust=0, vjust=0)

regresja4 <- pisaLP %>% lm(formula = scorePISARead ~ scorePISAMath) 
summary(regresja4)

#Podobnie jak w całej zbiorowości mamy tu do czynienia z wyraźną, choć nieco słabszą zależnością liniową. Współczynnik R kwadrat wynosi 0.56. 

#Zobaczmy teraz, co by się stało, gdyby omyłkowo ktoś wpisał źle jedną daną. Na wykresie powyżej celowo dodaliśmy etykiety do punktów oznaczających obserwacje, żeby wybrać taką, dla której wartość zmiennej niezależnej (wyniku testu z matematyki) będzie nietypowa. O obserwacjach takich mówimy, że mają wysoką dźwignię (leverage). Jeśli takie obserwacje znacząco odstają od linii regresji, może to mieć fatalne skutki dla całej analizy.

#Obserwacja o numerze 2288 ma bardzo niski wynik testu z matematyki. Zmienimy jej wynik testu z czytania na bardzo wysoki i powtrórzymy analizę regresji.

pisaLP <- pisaLP %>% mutate (scorePISARead = ifelse(id == 2288,800,scorePISARead))

pisaLP %>%
  ggplot(aes(scorePISAMath, scorePISARead)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  geom_text(aes(label=id),hjust=0, vjust=0)

regresja5 <- pisaLP %>% lm(formula = scorePISARead ~ scorePISAMath) 
summary(regresja5)

#Nadal mamy do czynienia z wyraźną zależnością liniową. Jednak współczynnik R kwadrat wynosi teraz zaledwie 0.34 (choć zmieniliśmy tylko jedną daną!). Regresja uległa także wypłaszczeniu. Porównajmy jej współczynniki:  

#bez obserwacji odstającej
coef(regresja4)
#z obserwacją odstającą
coef(regresja5)

#Wykrywaniu obserwacji odstających służą między innymi wykresy diagnostyczne regresji. R oferuje 6 takich wykresów, z czego domyślnie drukuje 4 z nich:

#pierwsza linijka umieszcza wszsytkie wykresy diagnostyczne na jednym obrazku. Jeśli jej zabraknie R będzie wyświetlał je jeden po drugim po naciśnięciu klawisza Enter
par(mfrow=c(2,2))
plot(regresja5)
par(mfrow=c(1,1))

#Obserwacje odstające znajdziemy na wykresie pierwszym, który na osi poziomej ma przewidywane wartości zmiennej zależnej a na osi pionowej wartość reszt. Możemy go narysować oddzielnie dodając etykiety danych:

plot(regresja5, 1, labels.id = pisaLP$id)

#Nieco lepszym sposobem odnajdywania obserwacji odstających jest ostatni domyślny wykres (o numerze 5), który na osi poziomej ma miarę dźwigni mierzącej jak bardzo dana obserwacja różni sie od innych pod względem wartości zmiennej niezależnej, a na osi pionowej wartość reszt. Największy wpływ na kształt regresji mają obserwacje o wysokiej dźwigni i wysokiej wartości bezwględnej reszty. Na poniższym wykresie R pokazuje także linie dla dwóch granicznych wartości odległości Cooka, która jest miarą wpływu danej jednostki obserwacji na kształt regresji. Odległość Cooka bliska jeden wskazuje na konieczność bliższego przyjrzenia się danej obserwacji.


plot(regresja5, 5, labels.id = pisaLP$id)

#Jeśli liczba obserwacji odstających jest niewielka, może wskazywać to na błędy kodowania danych. W takich wypadkach zwykle usuwa się te obserwacje z analizy:

regresja6 <- pisaLP %>% filter(id != 2288) %>% lm(formula = scorePISARead ~ scorePISAMath) 
summary(regresja6)

#R kwadrat wróciło dzięki temu zabiegowi do pierwotnego poziomu i wynosi 0.548. Porównajmy współczynniki regresji:  

#na początku
coef(regresja4)
#z obserwacją odstającą
coef(regresja5)
#po usunięciu obserwacji odstającej
coef(regresja6)

#Jeśli obserwacji odstających jest więcej, może to wskazywać, że istnieje jakaś grupa obiektów, dla których przebieg interesującej nas zależności jest inny niż dla pozostałych. Warto wówczas zastanowić się, jaka inna zmienna może nam pomóc zidentyfikować te obiekty.

## Zależność nieliniowa

#Czasami wartość współczynnika R kwadrat jest niska dlatego, że zależność między zmiennymi ma charakter nieliniowy. Żeby zobaczyć to na przykładzie użyjemy innych danych. Będą to dane z pakietu MASS dotyczące cen domów na przedmieściach Bostonu.

data("Boston", package = "MASS")
summary(Boston)

#Będzie nas interesowała zależność mediany wartości domu (*medv*) od udziału populacji o niskim statusie (*lstat*). Wyznaczmy najpierw regresję liniową.

Boston %>%
  ggplot(aes(lstat, medv)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

regBoston1 <- Boston %>% lm(formula = medv ~ lstat) 
summary(regBoston1)

#Widzimy tu wyraźną zależność negatywną - dla większych udziałów populacji o niskim statusie, przewidywana mediana wartości domu spada. Współczynnik R kwadrat wynosi 0.54 i jest dość wysoki. Jednak gdy spojrzymy na wykres, zobaczymy, że dla niskich udziałów populacji o niskim statusie narysowana prosta wydaje się słabo opisywać istniejącą zależność. Będzie to także widać na wykresach diagnostycznych regresji. Tym razem także spojrzymy na wykres pierwszy.

plot(regBoston1, 1)

#także jeśli uwolnimy naszą krzywą otrzymamy wynik odległy od prostej

Boston %>%
  ggplot(aes(lstat, medv)) +
  geom_point() +
  geom_smooth()

#Jeśli zależność między zmiennymi jest liniowa, czerwona linia na tym wykresie pokrywa się mniej więcej z zerem a reszty są rozłożone równomiernie po jej obu stronach. Widać, że nie jest to nasz przypadek. W takiej sytuacji można wykonać na przykład jedną z dwóch prostych operacji:

### Przekształcenie zmiennej

#Jednym z powszechnie stosowanych zabiegów jest zmiana skali zmiennej w taki sposób, żeby relacja nieliniowa stała się liniowa. Często używa się przy tym logarytmów. W naszym przykładzie wyglądałoby to tak:

Boston %>%
  ggplot(aes(log(lstat), medv)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

regBoston2 <- Boston %>% lm(formula = medv ~ log(lstat)) 
summary(regBoston2)

#Teraz prosta wydaje się o wiele lepiej dopasowana do danych, a R kwadrat wzrosło do 0.66. Także na wykresie diagnostycznym widzimy poprawę:

plot(regBoston2, 1)

### Dodanie czynnika kwadratowego 

#Alternatywną metodą jest zmiana postaci regresji. W naszym przypadku możemy na przykład dodać do niej czynnik kwadratowy. Regresję taką nazywamy regresją wielomianową, ponieważ po stronie zmiennych niezależnych pojawia się wielomian. W naszym przypadku będzie to wielomian drugiego stopnia w następującej postaci:

#medv = a + b\*lstat + c\*lstat<sup>2</sup>

regBoston3 <- Boston %>% lm(formula = medv ~ lstat + I(lstat^2)) 
summary(regBoston3)

#Tę samą regresję można także policzyć używając innej składni. Funkcja poly automatycznie tworzy wielomian. W naszym przypadku będzie to wielomian zmiennej *lstat* drugiego stopnia. Argument raw powstrzymuje R od tworzenia wielomianów ortogonalnych. 

regBoston3 <- Boston %>% lm(formula = medv ~ poly(lstat, 2, raw = TRUE)) 
summary(regBoston3)

#I tym razem obserwujemy znaczną poprawę dopasowania. R kwadrat wynosi 0.64, a wykres diagnostyczny wygląda tak:

plot(regBoston3, 1)

#Żeby narysować samą regresję wielomianową, trzeba zmienić formułę w wywołaniu funkcji :

Boston %>% ggplot(aes(lstat, medv)) +
  geom_point() +
  geom_smooth(method = lm, formula = y ~ poly(x, 2, raw = TRUE), se = F)

#Ta linia pasuje do danych lepiej niż prosta. Możliwe jednak, że wielomian wyższego stopnia byłby jeszcze lepiej dopasowany.

# Regresja wielokrotna

#Regresja wielomianowa jest szczególnym przypadkiem regresji wielokrotnej tj. takiej, w której wartość zmiennej niezależnej przewiduje się przy pomocy kilku zmiennych niezależnych. Nie muszą to być kolejne potęgi tej samej zmiennej. Mogą to być też zupełnie nowe zmienne. Ich dodawanie do regresji jest bardzo proste.

## Przykład regresji wielokrotnej

#Załóżmy, że chcemy sprawdzić w jaki sposób wynik testu z czytania zależy od wyniku testu z matematyki i od indeksu użytkowania biblioteki.

regwiel1 <- pisa %>% lm(formula = scorePISARead ~ scorePISAMath + libuse) 
summary(regwiel1)

#Przyjrzyjmy się znaczeniu współczynników w tym przykładzie:

coef(regwiel1)

#1. Przewydywany wynik testu z czytania dla osoby, która otrzymała zero punktów z testu z matematyki i dla której wartość indeksu użytkowania biblioteki wynosi zero, wynosi 109.2 punkta.

#2. Jeśli weźmiemy dwóch uczniów, z których pierwszy ma wynik testu z matematyki o 1 punkt wyższy niż drugi, ale obaj mają tę samą wartość indeksu użytkowania biblioteki, to przewidywany wynik testu z czytania dla ucznia pierwszego będzie o 0.793 punkta wyższy niż dla drugiego.

#2. Jeśli weźmiemy dwóch uczniów, z których pierwszy ma wartość indeksu użytkowania biblioteki o 1 punkt wyższy niż drugi, ale obaj mają tę sam wynik testu z matematyki, to przewidywany wynik testu z czytania dla ucznia pierwszego będzie o 5.2 punkta wyższy niż dla drugiego.

#Na podstawie powyższej interpretacji możnaby wysnuć wniosek, że korzystanie z biblioteki jest lepszym predyktorem wyniku testu z czytania niż wynik testu z matematyki. Nie jest to jednak takie proste, ponieważ indeks korzystania z bibilioteki i wynik testu z matematyki są wyrażone na bardzo różnych skalach, których nie można bezpośrednio porównywać. Widać to, kiedy spojrzymy na ich statystyki:

pisa %>% select(scorePISAMath, libuse) %>% summary

#Żeby móc porównać współczynniki nachylenia dla tych dwóch zmiennych, musimy użyć współczynników standaryzowanych. Niestety bazowy lm nie oferuje szybkiej standaryzacji współczynników. Jedną z metod ich uzyskania jest zestandaryzowanie zmiennych wkładanych do regresji. Można to zrobić przy użyciu funkcji *scale*.

regwiel2 <- pisa %>% lm(formula = scale(scorePISARead) ~ scale(scorePISAMath) + scale(libuse)) 
summary(regwiel2)

#Obliczony model jest dokładnie tym samym modelem co poprzednio i o tych samych współczynnikach dopasowania. Jednak jego współczynniki mają inną interpretację i mogą być porównywane. Widać tu, że

#2. Jeśli weźmiemy dwóch uczniów, z których pierwszy ma wynik testu z matematyki o 1 odchylenie standardowe wyższy niż drugi, ale obaj mają tę samą wartość indeksu użytkowania biblioteki, to przewidywany wynik testu z czytania dla ucznia pierwszego będzie o 0.841 odchylenia standardowego wyższy niż dla drugiego.

#2. Jeśli weźmiemy dwóch uczniów, z których pierwszy ma wartość indeksu użytkowania biblioteki o 1 odchylenie standardowe wyższą niż drugi ale obaj mają tę sam wynik testu z matematyki, to przewidywany wynik testu z czytania dla ucznia pierwszego będzie o 0.048 odchylenia standardowego wyższy niż dla drugiego. 

## Problem współliniowości

#Problemem często pojawiającym się w regresji wielokrotnej jest problem współliniowości. Zilustrujemy go na przykładzie wcześniej utworzonej zmiennej eksperyment która jest funkcją liniową scorePISARead i ich współczynnik korelacji liniowej wynosi jeden:

pisa %>% select(scorePISARead, eksperyment) %>% cor

#Zobaczmy, co się stanie jeśli obie te zmienne włożymy jako zmienne niezależne do regresji. Tym razem zmienną zależną będzie scorePISAMath:

regwiel3 <- pisa %>% lm(formula = scorePISAMath ~ scorePISARead + eksperyment)
summary(regwiel3)

#Zamieńmy kolejność zmiennych niezależnych.

regwiel4 <- pisa %>% lm(formula = scorePISAMath ~  eksperyment + scorePISARead)
summary(regwiel4)

#R nie oblicza nam współczynnika dla tej zmiennej, którą wymienimy jako drugą, ponieważ wpływ tej zmiennej na wielkość przewidywaną jest nieodróżnialny od wpływu zmiennej pierwszej. Prowadzi to do złego uwarunkowania macierzy używanej przy wyznaczaniu regresji.

#Nie zawsze jednak mamy do czynienia z tak dramatycznymi sytuacjami. Częściej zmienne niezależne są skorelowane wysoko ale nie całkowicie. Spójrzmy na przykład na korelację wyniku z matematyki i nauk przyrodniczych:

pisa %>% select(scorePISAMath, scorePISAScie) %>% cor

#Przy tak wysokiej korelacji możemy uzyskać równanie regresji, które będzie bardzo niestabilne. Spróbujmy wyznaczyć regresję wyniku z testu z czytania względem dwóch pozostałych testów oraz indeksu użytkowania biblioteki:

regwiel4 <- pisa %>% lm(formula = scorePISARead ~ scorePISAMath + scorePISAScie + libuse)
summary(regwiel4)

#Żeby ocenić, czy współlinowość predyktorów stanowi w tej sytuacji problem możemy użyć na przykład funkcji obliczającej czynnik inflacji wariancji (VIF) używając funkcji *vif* będącej elementem biblioteki *car* (Companion to Applied Regression).

if (!("car" %in% installed.packages()[, 1])) {
  install.packages("car")
}
library(car)
vif(regwiel4)

#Czynniki inflacji dla obu testów są dość wysokie. Co prawda zwykle jako wartość graniczną dla czynnika inflacji wariancji przyjmuje się 10. Są jednak autorzy, którzy rekomendują uważne przyjrzenie się wszystkim zmiennym, dla których VIF jest wyższy niż 2.5. To, razem z wiedzą o bardzo wysokiej korelacji (0.9), jest powodem do pewnego zmartwienia. Ostateczna decyzja należy do osoby analizującej. Przy bardzo wysokich współzależnościach między zmiennymi niezależnymi można po prostu usunąć jedną zmienną z regresji. 

# Inne założenia regresji liniowej

#Czytając o regresji można natknąć się na kilka dodatkowych założeń, takich jak homoskedastyczność czy multinormalność rozkładów błędów. Są one istotne wtedy, gdy jesteśmy zainteresowani wnioskowaniem o populacji na podstawie próby. Jeśli są Państwo nimi zainteresowani, doskonała jest ta seria [filmów edukacyjnych](https://www.youtube.com/playlist?list=PLTNMv857s9WUI1Nz4SssXDKAELESXz-bi).

#Tutaj przyjrzymy się jeszcze homoskedastyczności, która najczęściej może być żródłem problemów wnioskowania. 

#przykład z heteroskedastycznością

?trees

model1 <- lm(Volume~Height, data = trees)
par(mfrow = c(2, 2))
plot(model2)
par(mfrow = c(1, 1))

ggplot(trees, aes(Height, Volume)) +
  geom_point() +
  geom_smooth(method = "lm")

plot(model2, 1)

#problem widać na wykresie residuals vs fitted i na wykresie scale location pokazującym związek między kwadratami rezyduów a wartościami przewidywanymi

#Breusch–Pagan Test - dzieli zbiór wartości zmiennej niezależnej na kawałki i w każdym z nich wyznacza regresję a następnie sprawdza czy błędy standardowe współczynników są istotnie różne dla tych kawałków

library(lmtest)
lmtest::bptest(model1)

#white test - wyznacza regresję błędu względem zmiennej niezależnej i sprawdza czy jest istotna

install.packages("skedastic")
library(skedastic)
skedastic::white_lm(model1)


