library(readxl)
library(tidyr)
library(janitor)
library(ggplot2)
library(dplyr)
library(moments)

filePath <- paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/")
setwd(filePath)

samochody <- read.csv("samochody.csv")
#pink.slip is road worthiness certificate

regresja1 <- lm(Price ~ Age + Odometer, samochody)
summary(regresja1)


#relacje z tymu zmiennymi nie wydają się liniowe

samochody %>% ggplot(aes(Age, Price)) +
  geom_point()

samochody %>% ggplot(aes(Odometer, Price)) +
  geom_point()

regresja2 <- lm(Price ~ Age + I(Age^2) + I(1/Odometer), samochody)
summary(regresja2)

log(10,10)
log(100,10)
log(1000,10)
log(10000,10)

log(2.718)
log(7.389)
log(20.086)
log(54.598)

#spójrzmy na histogram liczników

ggplot(samochody) +
  geom_histogram(aes(x = Odometer), bins = 20,
                 fill = "cadetblue", color = "black")

#możemy "rozciągnąć" małe wartośći i "zbliżyć" duże dzięki logarytmom

ggplot(samochody) +
  geom_histogram(aes(x = log(Odometer)), bins = 20,
                 fill = "cadetblue", color = "black")

regresja3 <- lm(Price ~ Age + I(Age^2) + I(log(Odometer)), samochody)
summary(regresja3)

#kiedy logarytm wzrośnie o 1?

x = 5
log(x)
log(exp(1)*x)
log(exp(1)*x) - log(x)
log(exp(1)) + log(x)

#Współczynnik można zinterpretować kategoriach wzrostu wartości zmiennej niezależnej o 1%

log(1.01*x)
log(1.01) + log(x)
log(1.01)

#zatem jeśli podzielimy współczynnik na 100 to dostaniemy informację jak się zmieni przewidywana wartość zmiennej zależnej jeśli zmienna niezależna wzrośnie o 1%

-1079/100

#spójrzmy na histogram ceny

ggplot(samochody) +
  geom_histogram(aes(x = Price), bins = 20,
                 fill = "cadetblue", color = "black")

#możemy "rozciągnąć" małe wartośći i "zbliżyć" duże dzięki logarytmom

ggplot(samochody) +
  geom_histogram(aes(x = log(Price)), bins = 20,
                 fill = "cadetblue", color = "black")

regresja4 <- lm(I(log(Price)) ~ Age + I(Age^2) + I(log(Odometer)), samochody)
summary(regresja4)

(1.01^0.197 - 1)*100

#zmienna binarna jako zmienna niezalezna

regresja5 <- lm(Price ~ Pink.slip, samochody)
summary(regresja5)

regresja6 <- lm(I(log(Price)) ~ Age + I(Age^2) + I(log(Odometer)) + Pink.slip, samochody)
summary(regresja6)

#zmienna porządkowa jako zmienna niezależna

samochody %>% ggplot(aes(Age, Price)) +
  geom_point() +
  geom_vline(xintercept = 5, col = "red") +
  geom_vline(xintercept = 15, col = "red") +
  geom_vline(xintercept = 35, col = "red")

samochody <- samochody %>% mutate(Age_cat = case_when(
  Age <= 5 ~ 1,
  Age > 5 & Age <= 15 ~ 2,
  Age > 15 & Age <= 35 ~ 3,
  TRUE ~ 4))

samochody %>% count(Age_cat)

regresja7 <- lm(I(log(Price)) ~ Age_cat + I(log(Odometer)) + Pink.slip, samochody)
summary(regresja7)

samochody <- samochody %>% mutate(Age_cat = factor(Age_cat))

regresja7 <- lm(I(log(Price)) ~ Age_cat + I(log(Odometer)) + Pink.slip, samochody)
summary(regresja7)

samochody <- samochody %>% mutate(
  Age_cat2 = ifelse(Age_cat == 2,1,0),
  Age_cat3 = ifelse(Age_cat == 3,1,0),
  Age_cat4 = ifelse(Age_cat == 4,1,0))

regresja8 <- lm(I(log(Price)) ~ Age_cat2 + Age_cat3 + Age_cat4 + I(log(Odometer)) + Pink.slip, samochody)
summary(regresja8)

#interakcje
regresja9 <- lm(I(log(Price)) ~ Age_cat2 + Age_cat3 + Age_cat4 + I(log(Odometer)) + Pink.slip + Age_cat4*Pink.slip, samochody)
summary(regresja9)

#efekt Pink.slip dla vintage cars
0.123 + 1.3708

#przewidywanie dla samochodu z 1974 roku z przebiegiem 290000 km i jeżdzącym

exp(9.125 - 0.390 - 0.209*log(290) + 0.123 + 1.371)

#zmienna zależna binarna

regresja10 <- lm(Sold ~ Price, samochody)
summary(regresja10)

samochody %>% ggplot(aes(Price, Sold)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

regresja11 <-glm(Sold ~ Price, family=binomial(link="logit"), samochody)
summary(regresja11)

regresja12 <-glm(Sold ~ Price + Pink.slip, family = "binomial", samochody)
summary(regresja12)
exp(coef(regresja12))
