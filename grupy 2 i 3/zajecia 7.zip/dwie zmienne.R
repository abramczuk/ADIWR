library(readxl)
library(tidyr)
library(janitor)
library(ggplot2)
library(dplyr)
library(moments)

filePath <- paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/")
setwd(filePath)

pisa <- read_excel("PISA-2009-pogimnazjalne.xlsx", "data")
codebook <- read_excel("PISA-2009-pogimnazjalne.xlsx", "codebook")

# Rozkłady łączne wielu zmiennych

## Rozkłady łączne liczebności

#W rozkładzie łącznym grupy, których liczebność jest raportowana, powstają poprzez skrzyżowanie ze sobą wartości kilku (najczęściej dwóch, ale może być ich też więcej) zmiennych. Aby uzyskać zestawienie z takim rozkładem liczebności, w wywołaniu `count()` należy podać jako argumenty dodatkowe zmienne np.:
  
#  - rozkład łączny liczebności typu szkoły i płci:
 
pisa %>%
  count(schoolType, sex)

#łączny rozkład typu szkoły, płci i wieku:

# zaokrąglamy wiek 
pisa %>%
  mutate(age = factor(round(age, 0))) %>%
  count(schoolType, sex, age, .drop = FALSE)

#rozkład łączny liczebności na wykresie

## Skumulowany wykres liczebności w podgrupach

#Jeśli konstruując skumulowany wykres liczebności, przypiszemy jakąś inną zmienną do osi X lub Y, otrzymamy skumulowane wykresy liczebności w podgrupach ze względu na tę zmienną:

pisa %>% 
  ggplot() +
  geom_bar(aes(x = schoolType, fill = sex),
           color = "black") +
  xlab("typ szkoły") + ylab(NULL) +
  ggtitle("Liczba uczniów i uczennic w poszczególnych typach szkół") +
  scale_fill_hue()

#W praktyce tego rodzaju wykresy rzadko są przydatne do pokazania czegoś istotnego, ale w tym przypadku mają zastosowanie jako *krok pośredni* do stworzenia wykresu obrazującego rodzinę warunkowych rozkładów częstości. Częściej jest tak:

wykres <- pisa %>% 
  ggplot() +
  geom_bar(aes(x = schoolType, fill = sex),
           color  = "black", position = "dodge") +
  xlab("typ szkoły") + ylab(NULL) +
  ggtitle("Liczba uczniów i uczennic w poszczególnych typach szkół") +
  scale_fill_hue()
wykres

#Aczkolwiek i to najczęściej się zamienia na rodziny warunkowych rozkładów częstości. Zanim do nich przejdziemy:

## Rozkłady łączne częstości

#Rozkładem **łącznym** częstości nazywamy taki rozkład, który opisuje, jaką część **całej analizowanej zbiorowości** stanowią osoby należące do podgrup wyróżnionych ze względu na kombinację wartości danych zmiennych. 

#Jeśli dysponujemy łącznym rozkładem liczebności, to łączny rozkład częstości uzyskamy na jego podstawie w dokładnie ten sam sposób, co rozkład częstości jednej zmiennej na podstawie rozkładu liczebności jednej zmiennej:

rozkladlaczny <- pisa %>%
  count(schoolType, sex) %>%
  mutate(procent = n/nrow(pisa))
rozkladlaczny

library(scales) #tu jest funkcja formatująca skalę label_percent

rozkladlaczny %>% 
  ggplot(aes(x = schoolType, y = procent, fill = sex)) +
  geom_bar(color  = "black", position = "dodge", stat = "identity") +
  scale_y_continuous(labels = label_percent())

## Prezentowanie rozkładów łącznych w formie szerokiej

#Zestawienie w formie *ramki danych*, w której każda kombinacja wartości zmiennych opisywana jest w oddzielnym wierszu, jest wygodne z punktu widzenia przekształcanie danych (np. przeliczenia rozkładu liczebności na rozkład częstości). Nie jest ona jednak wygodna do oglądania rozkładu. W tym celu, jeśli jest to rozkład dwóch zmiennych, pożądane byłoby stworzenie tabeli, w której w wierszach znajdowałby się zestaw wartości jednej zmiennej, w kolumnach zestaw wartości drugiej zmiennej, a w komórkach na przecięciu danego wiersza i kolumny odpowiednia liczebność lub częstość.

#Aby uzyskać zestawienie w takiej formie, użyjemy funkcji `pivot_wider

#Potrzebne nam będą dwa argumenty:
  
#  - `names_from` wskazuje zmienną, której wartości mają zostać zapisane w kolumnach
#- `values_from` wskazuje zmienną, która zawiera wartości, które mają zostać umieszczone *wewnątrz* przygotowywanej tabeli

# rozkład z typem szkoły w wierszach i płcią w kolumnach
pisa %>%
  count(schoolType, sex)  %>%
  pivot_wider(names_from = sex,
              values_from = n)

# rozkład z typem szkoły w kolumnach i płcią w wierszach
pisa %>%
  count(schoolType, sex)  %>%
  pivot_wider(names_from = schoolType,
              values_from = n)

#Jeśli przygotowana przez nas *ramka danych* zawiera zarówno liczebności, jak i procenty, można łatwo umieścić je w oddzielnych kolumnach zestawienia – wystarczy podać jako argument `values_from` wektor kolumn
 
rozkladlaczny %>%
  pivot_wider(names_from = schoolType,
              values_from = c(n,procent))

#dalej analogicznie można dodawać np wiersze lub kolumny sum
#do tego samego zadania można też zaprząc woźnego

rozkladlaczny <- pisa %>%
  tabyl(schoolType, sex)
rozkladlaczny

rozkladlaczny %>%
  adorn_percentages("all") %>%
  adorn_pct_formatting(digits = 2) %>%
  adorn_ns()


#gdzie powinniśmy dodać sumy?

rozkladlaczny %>%
  adorn_totals(c("row", "col")) %>%
  adorn_percentages("all") %>%
  adorn_pct_formatting(digits = 2)

#możemy to narysować
wykres +
  scale_y_continuous(labels = scales::percent_format(scale = 100/nrow(pisa)))

# Tworzenie rodzin warunkowych rozkładów częstości

## Rodziny warunkowych rozkładów częstości

#W większości przypadków, aby móc wypowiadać się o związkach pomiędzy zmiennymi kategorialnymi, musimy posłużyć się porównywaniem tzw. **warunkowych rozkładów częstości**. Rozkład taki powstaje wtedy, kiedy tworzymy rozkład częstości jednej zmiennej w podgrupie wyróżnionej ze względu na określoną wartość drugiej zmiennej
  
#Jeśli zestawiamy obok siebie kilka warunkowych rozkładów częstości prezentujących rozkład jednej zmiennej w grupach wyróżnionych ze względu na poszczególne wartości drugiej zmiennej, to takie zestawienie określamy jako **rodzinę warunkowych rozkładów częstości**, np.:
  
#Występują w nich dwie zmienne, których nazwy łączone są przy pomocy wyrażeń takich jak *ze względu na* lub – nieco obszerniej i bardziej technicznie – *w (pod)grupach wyróżnionych ze względu na*. To, którą zmienną umieszczamy przed, a którą po takim wyrażeniu, ma związek z interpretacją ich wzajemnej relacji 

## Tworzenie rodzin warunkowych rozkładów częstości w pakiecie *dplyr*

#Aby stworzyć rodzinę warunkowych rozkładów częstości, musimy tylko nieznacznie zmodyfikować kod, przy pomocy którego utworzylibyśmy łącznych rozkład częstości dwóch zmiennych. 

#sprawdźmy jak szkoły różnią się tym, jak często ich uczniami są dziewczyny i chłopcy

rozkladlaczny %>%
  adorn_percentages("row") %>%
  adorn_pct_formatting(digits = 2)

#tym razem nie wszystkie procenty warto sumować

pisa %>% count(schoolType)

rozkladlaczny %>%
  adorn_totals("col") %>%
  adorn_percentages("row") %>%
  adorn_pct_formatting(digits = 2)

#ten sam rozkład w drugą stronę powie nam jak dziewczyny i chłopcy różnią się tym, jakie wybierają szkoły

rozkladlaczny %>%
  adorn_totals("row") %>%
  adorn_percentages("col") %>%
  adorn_pct_formatting(digits = 2)

#spróbujmy teraz narysowac rodzinę rozkładów warunkowych

pisa %>% 
  ggplot() +
  geom_bar(aes(x = schoolType, fill = sex),
           color = "black") +
  xlab("typ szkoły") + ylab(NULL) +
  ggtitle("Liczba uczniów i uczennic w poszczególnych typach szkół") +
  scale_fill_hue()

pisa %>% 
  ggplot() +
  geom_bar(aes(x = schoolType, fill = sex),
           color  = "black", position = "fill") +
  xlab("typ szkoły") + ylab(NULL) +
  ggtitle("Udział uczniów i uczennic w poszczególnych typach szkół") +
  scale_fill_hue()

pisa %>% 
  ggplot() +
  geom_bar(aes(y = sex, fill = schoolType),
           color  = "black", position = "fill") +
  xlab(NULL) + ylab("typ szkoły") +
  ggtitle("Udział poszczególnych typów szkół dla każdej płci") +
  scale_fill_hue()

## Rysowanie wykresu z gotowej tabeli z rozkładem

#W przykładach powyżej jako dane wejściowe do rysowania wykresu wykorzystaliśmy *ramkę danych* z *surowymi* danymi – funkcja `geom_bar()` sama zliczała wystąpienia poszczególnych wartości i ew. przeliczała je na częstości. Co zrobić w sytuacji, kiedy mamy gotową *ramkę danych* zawierającą rozkład i chcemy na jej podstawie narysować wykres?
  
#Stwórzmy *ramkę danych* z rodziną warunkowych rozkładów częstości typu szkoły ze względu na płeć.
#Zauważmy, że rozkład, musi być w postaci *długiej/wąskiej* (przed użyciem funkcji `pivot_wider()`), aby można go było wykorzystać do narysowania wykresu w *ggplot2*.
  
rozklad <- pisa %>%
  count(sex, schoolType, name = "pct") %>%
  group_by(sex) %>%
  mutate(pct = pct / sum(pct))

rozklad

#Takiej *ramki danych* też możemy użyć jako źródła danych, musimy jednak w wywołaniu funkcji `geom_bar()`:
  
#  - dodać argument `stat = "identity"`, który będzie wskazywał, że `geom_bar()` ma nie dokonywać już na danych żadnych obliczeń
#- w wywołaniu funkcji `aes()` przypisać do odpowiedniej osi wykresu kolumnę, która zawiera już obliczone częstości

ggplot(rozklad) +
  geom_bar(aes(y = sex, x = pct, fill = schoolType),
           position = "fill", stat = "identity")

#albo dla bezpośrednich porównań

wykres1 <- ggplot(rozklad) +
  geom_bar(aes(x = schoolType, y = pct, fill = sex),
           position = "dodge", stat = "identity", color = "black") +
  ggtitle("Rozkłady warunkowe") +
  scale_y_continuous(labels = scales::percent_format(scale = 100))
wykres1

#w porównaniu do:

wykres2 <- wykres +
  ggtitle("Rozkład łączny") +
  scale_y_continuous(labels = scales::percent_format(scale = 100/nrow(pisa)))
wykres2

#żeby ułatwić sobie porównanie:

install.packages("ggpubr")
library(ggpubr)

figure <- ggarrange(wykres1, wykres2,
                    ncol = 2, nrow = 1)
figure


#udział mężczyzn i kobiet jest podobny, więc to porównanie nie jest uderzające, ale jeśli podstawy procentowania znacznie się różnią różnice w tych dwóch ujęciach są wyrażne

# popatrzmy na wybierane szkoły ze względu na liczbę osób w gospodarstwie (do 3 włącznie) (miedzy 4 a 6) (powyzej 6)

pisa <- pisa %>% mutate(lgp = case_when(noPersHous < 4 ~ "small",
                                        pisa$noPersHous %in% c(4,5,6) ~ "average",
                                        noPersHous > 6 ~ "large")) %>% 
  mutate(lgp = factor(lgp, levels = c("small", "average", "large")))

pisa %>% count(pisa$lgp)

rozklad1 <- pisa %>% 
  filter(!is.na(lgp)) %>%
  ggplot() +
  geom_bar(aes(x = schoolType, fill = lgp),
           color  = "black", position = "dodge") +
  xlab("wielkość gospodarstwa") + ylab(NULL) +
  ggtitle("Rozkład łączny") +
  scale_fill_hue() +
  scale_y_continuous(labels = scales::percent_format(scale = 100/nrow(pisa)))
rozklad1

rozklad <- pisa %>%
  filter(!is.na(lgp)) %>%
  count(lgp, schoolType, name = "pct") %>%
  group_by(lgp) %>%
  mutate(pct = pct / sum(pct))
rozklad

rozklad2 <- ggplot(rozklad) +
  geom_bar(aes(x = schoolType, y = pct, fill = lgp),
           position = "dodge", stat = "identity", color = "black") +
  ggtitle("rozkłady warunkowe") +
  scale_y_continuous(labels = scales::percent_format(scale = 100))
rozklad2

figure <- ggarrange(rozklad1, rozklad2,
                    ncol = 2, nrow = 1)
figure

ggplot(rozklad) +
  geom_bar(aes(y = lgp, x = pct, fill = schoolType),
           position = "fill", stat = "identity")


