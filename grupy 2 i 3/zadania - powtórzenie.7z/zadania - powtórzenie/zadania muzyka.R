# Tu załaduj biblioteki

# Wczytaj dane music_genre.csv

# Są to dane muzyczne z serwisu Kaggle.com:
# https://www.kaggle.com/datasets/vicsuperman/prediction-of-music-genre

# Zadanie 1: Dane zawierają braki danych - przekoduj je w pliku:
# W kolumnie duration_ms -> -1
# W kolumnie tempo -> -99 
# W kolumnie instrumentalness -> -99.


# Zadanie 2: Przygotuj nową ramkę, która będzie zawierała wyłącznie zmienne id, acousticness i danceability. Uzyskaną ramkę przekształć do postaci długiej ze zmienną "measure" zawierającą nazwę mierzonej własności (acousticness i danceability) i zmienną "value" zawierającą wartość danej miary dla danej piosenki.


# Zadanie 3: Wyznacz wszytkie tercyle zmiennej popularity i Stwórz w zbiorze nową zmienną "pop_cat", która będzie factorem i która będzie przyjmowała wartości "low", "medium" i "high" dla utworów o popularności z pierwszego, drugiego i trzeciego tercyla.

#Zadanie 4
# Przygotuj rozkłady zmiennej pop_cat dla róznych gatunkow muzyki. 
# a) Rozkład łączny liczebności wraz z marginesami 
# b) Rodzinę rozkładów warunkowych kategorii popularności względem gatunku muzyki z odpowiednimi sumami 
# c) Narysuj rodzinę rozkładów warunkowych z podpunktu b na wykresie. Które gatunki ciezą ię największą, a które najmniejszą popularnością?

# Zadanie 5: Stwórz nową ramkę, która będzie zawierała wyłącznie dane o utworach z gatunku muzyka klasyczna. Zrób histogram i wykres pudełkowy długości trwania utworu (duration_ms) dla tej ramki. Podpisz osie i wykres.

# Zadanie 6: Stwórz zmienną duration_s tak, aby pokazywała liczbę sekund a nie milisekund (podziel duration_ms przez 1000). Policz średnią, wszystkie kwartyle, odchylenie standardowe i skośność czasu trwania utworu wyrażonego w sekundach.

# Zadanie 7: Oblicz średni czas trwania utworu dla utworóW różnych gatunków i przedstaw wyniki na wykresie. Do wykresu dodaj słupki błedów.

#Zadanie 8: Zrób regresję popularności utworóe rockowych względem długości trwania i danceability. Jak zinterpretowac parametry modelu? Sprawdź czy w zbiorze są jakieś obserwacje odstające, czy zależność faktycznie jest liniowa i czy współliniowość może stanowić problem.




