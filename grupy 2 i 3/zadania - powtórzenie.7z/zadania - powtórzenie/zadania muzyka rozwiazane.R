# Biblioteki Tidyverse
library("dplyr")
library("tidyr")
library("janitor")
library("ggplot2")
library("moments")

# Wczytanie danych 
filePath <- paste0(dirname(rstudioapi::getSourceEditorContext()$path), "/")
setwd(filePath)
fileName <- "music_genre.csv"

data <- read.csv(paste0(filePath, fileName))

# *Dzisiaj bedziemy pracowac na zbiorze danych muzycznych z serwisu Kaggle.com:
# https://www.kaggle.com/datasets/vicsuperman/prediction-of-music-genre

#### Zadania pod kolokwium.

# Zadanie 1: Dane zawierają braki danych - przekoduj je w pliku:
# W kolumnie duration_ms -> -1
# W kolumnie tempo -> -99 
# W kolumnie instrumentalness -> -99.

summary(data)
data <- data %>% 
  mutate(duration_ms = ifelse(duration_ms == -1, NA, duration_ms)) %>%
  mutate(tempo = ifelse(tempo == -99, NA, tempo)) %>%
  mutate(instrumentalness = ifelse(instrumentalness == -99, NA, instrumentalness))

# Zadanie 2: Przygotuj nową ramkę, która będzie zawierała wyłącznie zmienne id, acousticness i danceability. Uzyskaną ramkę przekształć do postaci długiej ze zmienną "measure" zawierającą nazwę mierzonej własności (acousticness i danceability) i zmienną "value" zawierającą wartość danej miary dla danej piosenki.

nowaramka <- data %>% select(instance_id, acousticness, danceability) %>% 
  pivot_longer(acousticness:danceability, names_to = "measure", values_to = "value")

# Zadanie 3: Wyznacz wszytkie tercyle zmiennej popularity i Stwórz w zbiorze nową zmienną "pop_cat", która będzie factorem i która będzie przyjmowała wartości "low", "medium" i "high" dla utworów o popularności z pierwszego, drugiego i trzeciego tercyla.

data <- data %>% mutate(pop_cat = case_when(
  popularity < quantile(popularity, 0.33) ~ "low" ,
  popularity > quantile(popularity, 0.33) & popularity < quantile(popularity, 0.66) ~ "medium",
  TRUE ~ "high"
)) %>% mutate(pop_cat = factor(pop_cat, levels = c("low", "medium", "high")))

data %>% tabyl(pop_cat)  

#Zadanie 4
# Przygotuj rozkłady zmiennej pop_cat dla róznych gatunkow muzyki. 
# a) Rozkład łączny liczebności wraz z marginesami 
# b) Rodzinę rozkładów warunkowych kategorii popularności względem gatunku muzyki z odpowiednimi sumami 
# c) Narysuj rodzinę rozkładów warunkowych z podpunktu b na wykresie. Które gatunki ciezą ię największą, a które najmniejszą popularnością?

data %>% 
  tabyl(pop_cat, music_genre) %>%
  adorn_totals(c("row", "col"))

data %>% 
  tabyl(pop_cat, music_genre) %>%
  adorn_percentages("col") %>%
  adorn_totals("row") %>%
  adorn_pct_formatting(2)

data %>% 
  count(pop_cat, music_genre) %>%
  group_by(music_genre) %>%
  mutate(n = n/sum(n)) %>%
  ggplot() +
  geom_bar(aes(x = music_genre, y = n, fill = pop_cat), stat = "identity")

# Zadanie 5: Stwórz nową ramkę, która będzie zawierała wyłącznie dane o utworach z gatunku muzyka klasyczna. Zrób histogram i wykres pudełkowy długości trwania utworu (duration_ms) dla tej ramki. Podpisz osie i wykres.

nowaramka2 <- data %>% filter(music_genre == "Classical")

ggplot(nowaramka2) +
  geom_histogram(aes(x = duration_ms)) +
  xlab("długość trwania utworu") +
  ylab("liczebności") +
  ggtitle("histogram dla muzyki klasycznej")

# Zadanie 6: Stwórz zmienną duration_s tak, aby pokazywała liczbę sekund a nie milisekund (podziel duration_ms przez 1000). Policz średnią, wszystkie kwartyle, odchylenie standardowe i skośność czasu trwania utworu wyrażonego w sekundach.

data <- data %>% mutate(duration_s = duration_ms/1000)
data %>% summary(duration_s)  
data %>% summarise_at("duration_s", list(sd, skewness), na.rm = T)

# Zadanie 7: Oblicz średni czas trwania utworu dla utworóW różnych gatunków i przedstaw wyniki na wykresie. Do wykresu dodaj słupki błedów.

parametry <- data %>%
  group_by(music_genre) %>%
  summarise(srM = mean(duration_s, na.rm = TRUE),
            sdM = sd(duration_s, na.rm = TRUE))

ggplot(parametry, 
       aes(x = music_genre, y = srM)) +
  geom_bar(stat = "identity",
           color = "black",
           position = "dodge") +
  geom_errorbar(aes(ymin=srM - sdM, ymax=srM+sdM), 
                width=.2,
                position = position_dodge(.9))

#Zadanie 8: Zrób regresję popularności utworóe rockowych względem długości trwania i danceability. Jak zinterpretowac parametry modelu? Sprawdź czy w zbiorze są jakieś obserwacje odstające, czy zależność faktycznie jest liniowa i czy współliniowość może stanowić problem.

datarock <- data %>% filter(music_genre == "Rock")
regresja <- lm(popularity ~ duration_s + danceability, datarock)
summary(regresja)

par(mar = c(1, 1, 1, 1))

par(mfrow=c(2,2))
plot(regresja)
par(mfrow=c(1,1))

if (!("car" %in% installed.packages()[, 1])) {
  install.packages("car")
}
library(car)
vif(regresja)





