library(readxl)
library(tidyr)
library(janitor)
library(ggplot2)
library(dplyr)
library(moments)

filePath <- paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/")
setwd(filePath)

pisa <- read_excel("PISA-2009-pogimnazjalne.xlsx", "data")
codebook <- read_excel("PISA-2009-pogimnazjalne.xlsx", "codebook")

#co jeśli jest dużo więcej wartości zmiennej

ggplot(pisa) +
  geom_bar(aes(x = scorePISAMath))

pisa %>% tabyl(scorePISAMath)

ggplot(pisa) +
  geom_histogram(aes(x = scorePISAMath))

## Histogram  

#Histogram ilustruje rozkład zmiennej poprzez *pocięcie* zakresu wartości, który ona przyjmuje, na przedziały (zwykle o równej szerokości) i narysowanie *słupków*, których wysokość jest proporcjonalna do liczby obserwacji w ramach danego przedziału. Aby go uzyskać, należy wykorzystać *geometrię* `geom_histogram()`, a w ramach wywołania funkcji `aes()` przypisać do osi X (albo do osi Y – jeśli chcemy mieć wykres w innej orientacji) zmienną, której rozkład chcemy zwizualizować. Na początek stwórzmy wykres obrazujący rozkład wyników testu PISA z matematyki:

#Takie domyślne wywołanie poskutkuje informacją, że byłoby lepiej, gdybyśmy sami wskazali funkcji `geom_histogram()`, na ile przedziałów ma zostać podzielony zakres wartości, które przyjmuje zmienna. Można to zrobić na jeden z trzech sposobów:

#- argumentem `bins` – podając liczbę przedziałów
#- argumentem `binwidth` – podając szerokość przedziału
#- argumentem `breaks` – podając wektor zawierający *punkty cięcia*
#- z tej opcji warto skorzystać, jeśli chce się zachować ten sam podział na kilku niezależnie od siebie generowanych histogramach
#- można w ten sposób zdefiniować przedziały, które nie są równej szerokości, ale w praktyce raczej nie znajdziemy się w sytuacji, w której miałoby to sens

#Aby pokolorować *słupki* lub nadać im obramowanie, można użyć argumentów `fill` i `color`, przy czym lepiej podać je jako argumenty `geom_histogram()`, a nie `aes()`.

#Zmodyfikujmy wygenerowany wcześniej wykres, zwiększając liczbę przedziałów do 100 i dodając kolory:

ggplot(pisa) +
  geom_histogram(aes(x = scorePISAMath), bins = 100,
                 fill = "cadetblue", color = "black")

ggplot(pisa) +
  geom_histogram(aes(x = scoreTMR), bins = 50,
                 fill = "cadetblue", color = "black")

ggplot(pisa) +
  geom_histogram(aes(x = escs), bins = 100,
                 fill = "cadetblue", color = "black")

ggplot(pisa) +
  geom_histogram(aes(x = income), bins = 30,
                 fill = "cadetblue", color = "black")

dane <- pisa %>% select(id, scorePISAMath, scoreTMR, escs, income)  

dane %>% pivot_longer(-id,names_to = "measure", values_to = "value") %>%
  ggplot(aes(x = value)) +
  geom_histogram(fill = "cadetblue", color = "black") +
  facet_wrap(~measure, scales = "free")

#obliczamy średnie dla tych różnych zmiennych

mean(pisa$scorePISAMath)
mean(pisa$scoreTMR)
mean(pisa$scoreTMR, na.rm = TRUE)

#Wynik wywołania ww. funkcji sam jest wektorem liczbowym, tyle że składającym się tylko z jednego elementu. Możemy przypisać go do obiektu:

# Funkcja `summarise()`

#Jedną z podstawowych funkcjonalności, jakie oferuje pakiet *dplyr*, jest łatwe tworzenie zestawień statystyk, charakteryzujących analizowane przez nas dane. Służy do tego przede wszystkim funkcja `summarise()`. W najprostszej sytuacji zwróci ona *tibble* (*ramkę danych*) zawierającą jeden wiersz i zmienne opisujące wartości parametrów, które nakazaliśmy obliczyć dla konkretnych zmiennych przy pomocy następnych argumentów.

#Np. chcąc obliczyć średnią i odchylenie standardowe zmiennej `scorePISAMath`, możemy użyć kodu:

parametry <- summarise(dane,
                       minimum = min(scorePISAMath),
                       srednia = mean(scorePISAMath),
                       maksimum = max(scorePISAMath))
parametry

#Uwaga: przekształcenia definiowane w wywołaniu funkcji `summarise()` wykonywane są w kolejności, w jakiej zostały zapisane, i jeśli w którymś z dalszych przekształceń zostanie użyta nazwa zmiennej, która *została już wcześniej obliczona*, to zostanie wykorzystana ta wcześniej obliczona wartość statystyki opisowej. 

# Obliczanie tych samych parametrów dla wielu zmiennych jednocześnie

#Jeśli ten sam zestaw parametrów chcemy obliczyć dla wielu zmiennych jednocześnie, pisanie kodu opisującego, co chcemy policzyć oddzielnie dla każdej z nich może być bardzo uciążliwe. Problem ten pozwala rozwiązać użycie funkcji `summarise_all()`. Jak wskazuje nazwa, pozwala ona dokonać obliczeń dla wszystkich zmiennych przekazanej jej *ramki danych*. Aby jej użyć, musimy przygotować *ramkę danych* zawierającą tylko te zmienne, które nas interesują.

#Jako pierwszy argument funkcja `summarise_all()` przyjmuje ramkę danych. Drugi służy do podania, jakie statystyki mają zostać obliczone. W najprostszym sposobie użycia ma on postać listy (tworzonej przy pomocy funkcji `list()`), której kolejne elementy mają postać: `sufiks = funkcja`, gdzie:

#  - `sufiks` to przyrostek, który będzie dopisywany w zwróconej ramce danych do nazw kolumn, które będą zawierały daną statystykę
# - `funkcja` to nazwa funkcji, która oblicza daną statystykę (uwaga! to nie jest wywołanie tej funkcji - po nazwie nie zapisujemy nawiasów okrągłych)

#Np. aby obliczyć średnią i odchylenie standardowe dla każdego z testów PISA, możemy użyć kodu:

parametry <- summarise_all(dane[-1],
              list(minimum = min,
                   srednia = mean,
                   maksimum = max))

#Jeśli chcemy przekazać do funkcji liczących statystyki opisowe jakiś dodatkowy argument, np. `na.rm = TRUE`, można podać go jako dodatkowy, trzeci argument wywołania `summarise_all()`:

parametry <- summarise_all(dane,
                           list(minimum = min,
                                srednia = mean,
                                maksimum = max),
                           na.rm = TRUE)

parametry <- dane %>% pivot_longer(-id,names_to = "measure", values_to = "value")  %>% group_by(measure) %>% summarise(srednia = mean(value, na.rm = TRUE))

#dodamy średnie do histogramów

ggplot(pisa) +
  geom_histogram(aes(x = scorePISAMath), bins = 100,
                 fill = "cadetblue", color = "black") +
  geom_vline(aes(xintercept = mean(scorePISAMath)), col='red',size=2)

dane %>% pivot_longer(-id,names_to = "measure", values_to = "value") %>%
  ggplot(aes(x = value)) +
  geom_histogram(fill = "cadetblue", color = "black") +
  facet_wrap(~measure, scales = "free") +
  geom_vline(data = parametry, aes(xintercept = srednia), col='red',size=2)

## Wykres *skrzypcowy*

#Figura prezentowana na wykresie *skrzypcowym* to wygładzony histogram, który został połączony ze swoim *lustrzanym odbiciem* (względem osi, na której leży). Rozkład wyników testu PISA z matematyki, który powyżej wizualizowaliśmy na histogramie, w postaci wykresu *skrzypcowego* wygląda tak (w odróżnieniu od histogramu *skrzypce* zwykle rysuje się w orientacji pionowej):

ggplot(pisa) +
  geom_violin(aes(x = "", y = scorePISAMath),
              fill = "cadetblue") +
  xlab(NULL)

#Aby uzyskać wykres *skrzypcowy*, należy użyć funkcji `geom_violin()`. Zwróćmy uwagę, że, w odróżnieniu od `geom_histogram()` wymaga ona przypisania w ramach wywołania `aes()` jakiejś wartości zarówno do osi X, jak i do osi Y. W związku z tym, jeśli chcemy zilustrować rozkład jednej zmiennej, do drugiej osi musimy przypisać jakąś umowną pojedynczą wartość, np. pusty ciąg znaków.

ggplot(pisa) +
  geom_violin(aes(x = "", y = scorePISAMath),
              draw_quantiles = c(0.25, 0.5, 0.75),
              fill = "cadetblue") +
  xlab(NULL)

#Podanie argumentu `draw_quantiles` jest opcjonalne. Jeśli to zrobimy, linie wewnątrz *skrzypiec* będą pokazywać wartości podanych kwatnyli (na wykresie powyżej: 1. kwartyla, mediany i 3. kwartyla).

#Porównajmy dla naszych wybranych zmiennych

 dane %>% pivot_longer(-id,names_to = "measure", values_to = "value") %>%
  ggplot() +
  geom_violin(aes(x = "", y = value), 
              draw_quantiles = c(0.25, 0.5, 0.75),
              fill = "cadetblue", color = "black") +
  facet_wrap(~measure, scales = "free") 

dane %>% pivot_longer(-id,names_to = "measure", values_to = "value") %>%
  ggplot() +
  geom_violin(aes(x = "", y = value), 
              draw_quantiles = c(0.25, 0.5, 0.75),
              fill = "cadetblue", color = "black") +
  facet_wrap(~measure, scales = "free") +
  geom_hline(data = parametry, aes(yintercept = srednia), col='red',size=1)

#możemy też narysować inne kwantyle

#możemy obliczyć kwantyle podobnie jak wcześniej liczyliśmy średnie. Na przykład:

parametry <- dane %>% 
  pivot_longer(-id,names_to = "measure", values_to = "value")  %>% 
  group_by(measure) %>% 
  summarise(srednia = mean(value, na.rm = TRUE),
            kwa10 = quantile(value, 0.10, na.rm = TRUE),
            kwa90 = quantile(value, 0.90, na.rm = TRUE))

parametry

#wykorzystajmy to, żeby porównać medianę i średnią

parametry <- dane %>% 
  pivot_longer(-id,names_to = "measure", values_to = "value")  %>% 
  group_by(measure) %>% 
  summarise(srednia = mean(value, na.rm = TRUE),
            mediana = quantile(value, 0.50, na.rm = TRUE))
parametry

parametry <- parametry %>% mutate(roznica = mediana - srednia) 

# to czy te różnice są duże jest rzeczą względną.

# standardowe zróżnicowanie mierzy się odchyleniem standardowym (lub wariancją)

maledane <- tibble(id = as.factor(c(1:4)), wiek = c(1,3,4,8))
mean(maledane$wiek)

maledane %>% 
  ggplot(
    aes(x=id, y=wiek, label=wiek)) + 
  geom_hline(aes(yintercept = 4), color = "red", size = 1) +
  geom_point(stat='identity', size=6) +
  geom_segment(aes(y = wiek, 
                   x = `id`, 
                   yend = mean(wiek), 
                   xend = `id`), 
               color = "black",
               size = 2) +
  geom_text(color="white", size=4) +
  coord_flip()

#gdybyśmy chcieli policzyć wariancję na piechotę:
(3^2+1^2+0+4^2)/4
#odchylenie standardowe
sqrt(6.5)

#jeśli użyjemy funkcji wbudowanych w R
var(maledane$wiek)
sd(maledane$wiek)

#funkcje te wyznaczają nieobciążony estymator wariancji i odchylenia standardowego dla prostej niezależnej próby losowej
#żeby wyznaczyć wartości populacyjne musimy dla wariancji wymnożyć wynik przez (n-1)/n

n = nrow(maledane)
var(maledane$wiek)*(n-1)/n
sd(maledane$wiek)*sqrt((n-1)/n)

#przyjrzyjmy się co mierzy ten parametr

pisa %>% 
  ggplot(aes(x = scorePISAMath)) +
  geom_histogram(fill = "cadetblue", color = "black") +
  facet_wrap(~sex)

pisa %>% 
  group_by(sex) %>% 
  summarise(srednia = mean(scorePISAMath),
            kwa10 = quantile(scorePISAMath, 0.10, na.rm = TRUE),
            kwa90 = quantile(scorePISAMath, 0.90, na.rm = TRUE),
            wariancja = var(scorePISAMath),
            odchylenie = sd(scorePISAMath)) 

pisa %>% 
  group_by(sex) %>% 
  summarise_at("scorePISAMath",
               list(srednia = mean,
                    kwa10 = quantile(x, 0.10),
            wariancja = var,
            odchylenie = sd),
            na.rm = TRUE)

#popatrzmy na inne testy

pisa %>% select(sex, contains("PISA")) %>%
  group_by(sex) %>% 
  summarise_all(list(o = sd))

pisa %>% select(sex, contains("PISA")) %>%
  pivot_longer(2:4,names_to = "test", values_to = "value") %>%
  ggplot() +
  geom_histogram(aes(x = value), bins = 30,
                 fill = "cadetblue", color = "black") +
  facet_grid(test ~ sex, scales = "free_y")

#zobaczmy teraz, jak to się ma do różnic między średnią a medianą

parametry <- dane %>% 
  pivot_longer(-id,names_to = "measure", values_to = "value")  %>% 
  group_by(measure) %>% 
  summarise(srednia = mean(value, na.rm = TRUE),
            mediana = quantile(value, 0.50, na.rm = TRUE),
            roznica = mediana - srednia,
            odch = sd(value, na.rm = TRUE),
            roznicast = roznica/odch)

parametry

#popatrzmy na wykres income

ggplot(pisa) +
  geom_histogram(aes(x = income), bins = 30,
                 fill = "cadetblue", color = "black") +
  geom_vline(aes(xintercept = mean(income, na.rm = TRUE)), col='red',size=2) +
  geom_vline(aes(xintercept = quantile(income, 0.5, na.rm = TRUE)), col='green',size=2)

#miara, która to opisuje to skośność rozkładu 
#można ją policzyć na piechotę albo skorzystać z biblioteki moments
#w miatę symetryczne rozkłady mają skośność między -0.5 a +0.5

install.packages("moments")
library(moments)

parametry <- dane %>% 
  pivot_longer(-id,names_to = "measure", values_to = "value")  %>% 
  group_by(measure) %>% 
  summarise(srednia = mean(value, na.rm = TRUE),
            mediana = quantile(value, 0.50, na.rm = TRUE),
            skosnosc = skewness(value, na.rm = TRUE))
parametry

#ujemna skośność

ggplot(pisa) +
  geom_histogram(aes(x = scoreTMR), bins = 30,
                 fill = "cadetblue", color = "black") +
  geom_vline(aes(xintercept = mean(scoreTMR, na.rm = TRUE)), col='red',size=2) +
  geom_vline(aes(xintercept = quantile(scoreTMR, 0.5, na.rm = TRUE)), col='green',size=2)

#współcześnie skośność definiuje się średni standaryzowany sześcian odchyleń od średniej 

#relacja między średnią i medianą nie musi determinować wartości skośności

## Wykresy *pudełkowy*

#Wykres pudełkowy ilustruje rozkład zmiennej w nieco mniej szczegółowy sposób niż wcześniej omawiane (tak jak w przypadku wykresu *skrzypcowego* trzeba przypisać wartości do oby osi wykresu):

ggplot(pisa) +
  geom_boxplot(aes(x = "", y = scorePISAMath),
               fill = "cadetblue") +
  xlab(NULL)


ggplot(pisa) +
  geom_boxplot(id ~ scorePISAMath,
               fill = "cadetblue",
               id.method = "id") +
  xlab(NULL)
#Granice *pudełka* rysowanego przez funkcję `geom_boxplot()` opisują:
#- 1. kwartyl –  dolna krawędź
#- medianę –  linia wewnątrz *pudełka*
#- 3. kwartyl –  górna krawędź

#Linie sięgające poza pudełko to tak zwane *wąsy* i służą one do zaznaczenia, jaki jest zakres, który przyjmują wartości danej zmiennej –  w szczególności, czy niektóre obserwacje nie mają *nietypowo* niskich/wysokich wartości. 

#- Jako kryterium *nietypowości* przyjmowane jest odbieganie od 1. kwartyla (w dół) lub od 3. kwartyla (w górę) o więcej niż 1,5 rozstępu ćwiartkowego (tj. różnicy pomiędzy wartością 3. kwartyla a wartością 1. kwartyla).
#- Wartości zmiennej dla takich *nietypowych* obserwacji (o ile występują) zaznaczane są na wykresie w postaci kropek.
#- Jeśli *z danej strony* występują jakieś obserwacje *nietypowe*, to *wąs* sięga do zdefiniowanego powyżej *progu nietypowości*.
#- Jeśli *z danej strony* nie występują żadne obserwacje *nietypowe*, to *wąs* sięga do odpowiednio minimalnej lub maksymalnej wartości, jaką przyjmuje dana zmienna.?

#popatrzmy na nasze zmienne

dane %>% pivot_longer(-id,names_to = "measure", values_to = "value") %>%
  ggplot() +
  geom_boxplot(aes(x = "", y = value),
               fill = "cadetblue") +
  facet_wrap(~measure, scales = "free") +
  xlab(NULL)

#żeby poradzić sobie z rozkładami o dużej skośności/wielu outlierach można też liczyć średnią obciętą

parametry <- dane %>% 
  pivot_longer(-id,names_to = "measure", values_to = "value")  %>% 
  group_by(measure) %>% 
  summarise(srednia = mean(value, na.rm = TRUE),
            mediana = quantile(value, 0.50, na.rm = TRUE),
            skosnosc = skewness(value, na.rm = TRUE),
            srednia90 = mean(value, trim = 0.1, na.rm = TRUE))
parametry

#najważniejsze parametry dla całego zbioru można wyznaczyć uzywając polecenie summary

summary(pisa)


