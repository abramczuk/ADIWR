library(readxl)
library(tidyr)
library(janitor)
library(ggplot2)
library(dplyr)
library(moments)

filePath <- paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/")
setwd(filePath)

pisa <- read_excel("PISA-2009-pogimnazjalne.xlsx", "data")
codebook <- read_excel("PISA-2009-pogimnazjalne.xlsx", "codebook")


# Ilustrowanie związków pomiędzy zmienną kategorialną a zmienną ciągłą

## Wykresy *skrzypcowe* i *pudełkowe*

#Jeśli chcemy porównać ze sobą rozkłady zmiennej ciągłej w grupach wyróżnionych ze względu na zmienną kategorialną (ogólnie rzecz biorąc: przyjmującą, przynajmniej w analizowanym zbiorze, niewiele różnych wartości), możemy do tego łatwo wykorzystać  funkcje `geom_violin()` lub `geom_boxplot()` –  wystarczy w wywołaniu `aes()` przypisać zmienną grupującą do drugiej osi wykresu.

#Wykres obrazujący związek między typem szkoły a wynikami testu PISA z matematyki można więc uzyskać tak:
  
ggplot(pisa) +
  geom_violin(aes(x = schoolType,
                  y = scorePISAMath),
              draw_quantiles = c(0.25, 0.5, 0.75),
              fill = "cadetblue")

#albo tak:
  
ggplot(pisa) +
  geom_boxplot(aes(x = schoolType,
                   y = scorePISAMath), fill = "cadetblue")

## Wyróżnienie grup kolorem

#Zamiast opisywać grupy etykietami na osi wykresu możemy wyróżnić je kolorem wypełnienia. W takim przypadku zmienna grupująca powinna zostać w ramach wywołania `aes()` podana argumentem `fill`:
  
ggplot(pisa) +
  geom_violin(aes(x = "",
                  y = scorePISAMath,
                  fill = schoolType),
              draw_quantiles = c(0.25, 0.5, 0.75)) +
  xlab(NULL)

ggplot(pisa) +
  geom_boxplot(aes(x = "",
                   y = scorePISAMath,
                   fill = schoolType)) +
  xlab(NULL)


## Grupowanie ze względu na skategoryzowaną zmienną ciągłą

# Niekiedy możemy chcieć utworzyć grupy na podstawie zmiennej ciągłej, poprzez *pocięcie jej* na przedziały. W tym celu możemy posłużyć się funkcją `cut()` –  jako pierwszy argument przyjmuje ona wektor liczbowy, który ma zostać *pocięty*, a jako drugi wektor granic definiujących przedziały (**uwaga! musi on zawierać również dolną granicę pierwszego przedziału i górną granicę ostatniego**). Zwróćmy uwagę, że wywołanie funkcji `cut()` (i dowolnej innej funkcji) można zapisać w ramach wywołania `aes()` (w takim przypadku przekształcenie nie zostanie zapisane w *ramce danych*, na podstawie której rysowany jest wykres, ale przyniesie oczekiwany skutek w kontekście rysowania wykresu):

ggplot(pisa) +
  geom_violin(aes(x = cut(age, 15:21),
                  y = scorePISAMath),
              draw_quantiles = c(0.25, 0.5, 0.75),
              fill = "cadetblue") +
  xlab("przedział wieku")

ggplot(pisa) +
  geom_boxplot(aes(x = cut(age, 15:21),
                   y = scorePISAMath), fill = "cadetblue") +
  xlab("przedział wieku")


#Zmienna `age()` zawierała braki danych, więc taka grupa również pojawiła się na wykresach. Zwróćmy uwagę, że dla grup, które zawierają bardzo mało obserwacji, `geom_violin()` może nie być w stanie nic narysować. Sprawdźmy, jak liczne są wyróżnione przez nas grupy:
  
pisa %>%
  count(cut(age, 15:21))

## Wykresy składające się z wielu *paneli*

#Istnieje jeszcze jedna możliwość, aby na jednym wykresie zestawić obok siebie wizualizacje rozkładów danej zmiennej w różnych grupach, a mianowicie użycie znanej nam już funkcji `panel_wrap()` lub `panel_grid()`. Pozwalają one stworzyć wykres składający się z wielu *paneli*. Zastosujmy pierwszą z nich w połączeniu z histogramem:

ggplot(pisa) +
  geom_histogram(aes(x = scorePISAMath), bins = 50,
                 fill = "cadetblue", color = "black") +
  facet_wrap(~schoolType)

#Zmienną, która definiuje podział na panele, podaje się jako pierwszy argument funkcji `facet_wrap()`, przy czym jej nazwę należy poprzedzić znakiem "~" (tj. podać jako *formułę*).

#Zwróćmy uwagę, że domyślnie skale osi na każdym z *paneli* mają identyczny zakres. Jeśli chcemy porównać kształt rozkładu w grupach, które bardzo różnią się liczebnością, może nam to przeszkadzać (np. w porównaniu do liczby uczniów LO liczba badanych w LP jest tak mała, że trudno ocenić kształt rozkładu w tej grupie). Aby dostosować skale na każdym z *paneli* do rozpiętości wartości w ramach danej grupy, należy użyć dodatkowego argumentu `scales`. Z kolei przy pomocy argumentów `nrow` lub `ncol` można wskazać, w jaki sposób panele mają zostać ułożone.

#Aby łatwo porównać ze sobą rozkłady w różnych typach szkół, *uwolnijmy* skale na osi Y i ułóżmy je w jednej kolumnie:
  
ggplot(pisa) +
  geom_histogram(aes(x = scorePISAMath), bins = 50,
                 fill = "cadetblue", color = "black") +
  facet_wrap(~schoolType, ncol = 1, scales = "free_y")

#Funkcja `facet_grid()` pozwala wykorzystać do zdefiniowania podziału na *panele* dwie zmienne, np. typ szkoły i płeć:
  
ggplot(pisa) +
  geom_histogram(aes(x = scorePISAMath), bins = 50,
                 fill = "cadetblue", color = "black") +
  facet_grid(schoolType ~ sex, scales = "free_y")

#Nazwę zmiennej, która będzie prezentowana *w pionie*, należy podać przed znakiem "~", a nazwę zmiennej, która ma być prezentowana *w poziomie*, po nim.

#Zwróćmy uwagę, że argument *scales = "free_y"* sprawia, że skale na osi Y różnią się pomiędzy *panelami* znajdującymi się w różnych wierszach, ale w ramach danego wiersza skala osi Y jest ta sama. Na naszym wykresie ma to taki skutek, że daje się zauważyć różnice w rozkładzie płci pomiędzy szkołami (LO są bardziej *sfeminizowane*, a szkoły kształcące zawodowo bardziej *zmaskulinizowane*).

## Wykresy słupkowe ilustrujące wartość wybranego parametru poziomu wartości

#Omawiane powyżej wykresy zawierały informacje pozwalające rekonstruować kształt całego rozkładu, jednak **często chcemy zawrzeć na wykresie znacznie prosty przekaz – porównać ze sobą wartości jednego wybranego parametru rozkładu (zwykle po prostu średniej) w ramach grup**. Do tego celu bardzo dobrze sprawdza się zwykle wykres słupkowy/kolumnowy, narysowany na podstawie wcześniej obliczonej ramki danych. Schemat postępowania jest w takiej sytuacji następujący:
  
#  1. Przygotowujemy *ramkę danych* z obliczonymi wartościami wybranego parametru danej zmiennej w poszczególnych grupach (można do tego użyć funkcji `group_by()` i `summarise()`).
#2. Przy pomocy *geometrii* `geom_bar()` rysujemy wykres słupkowy/kolumnowy, podając argument `stat = "identity"`, aby zaznaczyć, że nie chodzi nam o zliczanie obserwacji w ramach przekazanych danych, ale narysowanie *słupków* po prostu o zadanej wysokości (szerokości).

#Przykładowo, aby zaprezentować różnice średnich wyników testu PISA z matematyki w poszczególnych typach szkół, można wykonać:
  
srednieTypSzkoly <- pisa %>%
  group_by(schoolType) %>%
  summarise(srScorePISAMath = mean(scorePISAMath, na.rm = TRUE))

# taką ramkę danych uzyskaliśmy
srednieTypSzkoly

# a teraz narysujemy na jej podstawie wykres
ggplot(srednieTypSzkoly) +
  geom_bar(aes(x = schoolType,
               y = srScorePISAMath),
           stat = "identity",
           fill = "cadetblue", color = "black")

#Jeśli przeprowadzimy grupowanie wg dwóch zmiennych, możemy skonstruować nieco bardziej złożony wykres, w którym np. w ramach każdego typu szkoły będziemy zestawiać ze sobą *słupki* opisujące średnie wyniki każdej z płci:

srednieTypSzkoly <- pisa %>%
  # teraz grupujemy zaróWno po typie szkoły, jak i po płci
  group_by(schoolType, sex) %>%
  summarise(srScorePISAMath = mean(scorePISAMath, na.rm = TRUE))

# taką ramkę danych uzyskaliśmy
srednieTypSzkoly

# a teraz narysujemy na jej podstawie wykres
ggplot(srednieTypSzkoly) +
  geom_bar(aes(x = schoolType,
               y = srScorePISAMath,
               fill = sex),
           stat = "identity",
           color = "black",
           # żeby słupki były ustawione koło siebie:
           position = "dodge")

#do takiego wykresu często dodaje się "wąsy" błedów
#czasami są to po prostu odchylenia standardowe

srednieTypSzkoly <- pisa %>%
  # teraz grupujemy zaróWno po typie szkoły, jak i po płci
  group_by(schoolType, sex) %>%
  summarise(srM = mean(scorePISAMath, na.rm = TRUE),
            sdM = sd(scorePISAMath, na.rm = TRUE))

# Use 95% confidence intervals instead of SEM
ggplot(tgc2, aes(x=dose, y=len, fill=supp)) + 
  geom_bar(position=position_dodge(), stat="identity") +
  geom_errorbar(aes(ymin=len-ci, ymax=len+ci),
                width=.2,                    # Width of the error bars
                position=position_dodge(.9))


ggplot(srednieTypSzkoly, 
       aes(x = schoolType, y = srM, fill = sex)) +
  geom_bar(stat = "identity",
           color = "black",
           # żeby słupki były ustawione koło siebie:
           position = "dodge") +
  geom_errorbar(aes(ymin=srM - sdM, ymax=srM+sdM), 
                width=.2,
                position = position_dodge(.9))

#czesciej używa się 95% przedziału ufności

srednieTypSzkoly <- pisa %>%
  # teraz grupujemy zaróWno po typie szkoły, jak i po płci
  group_by(schoolType, sex) %>%
  summarise(srM = mean(scorePISAMath, na.rm = TRUE),
            sdM = sd(scorePISAMath, na.rm = TRUE),
            nM = sum(!is.na(scorePISAMath)),
            seM = sdM/sqrt(nM),
            ciM = qt((.95+1)/2, nM-1)*seM)

srednieTypSzkoly

ggplot(srednieTypSzkoly, 
       aes(x = schoolType, y = srM, fill = sex)) +
  geom_bar(stat = "identity",
           color = "black",
           # żeby słupki były ustawione koło siebie:
           position = "dodge") +
  geom_errorbar(aes(ymin=srM - ciM, ymax=srM+ciM), 
                width=.2,
                position = position_dodge(.9))

#Zwróćmy uwagę, że aby *słupki* opisujące płeć były ustawione w ramach typu szkoły obok siebie (a nie jeden na drugim – jak to się dzieje domyślnie), do wywołania `geom_bar()` trzeba było dodać jeszcze argument `position = "dodge"`.

#w analogiczny sposób możemy porównywać wartości innych parametrów rozkładu między grupami

# Ilustrowanie związków pomiędzy dwiema zmiennymi ciągłymi

# Wykresy rozrzutu

#Wykres rozrzutu można utworzyć przy pomocy funkcji `geom_point()`, w wywołaniu funkcji `aes()` przypisując jedną zmienną do osi X, a drugą do osi Y, np.:

ggplot(pisa) +
  geom_point(aes(x = scorePISAMath, y = scorePISARead)) 

#Choć przy tak dużej liczbie obserwacji, nie sprawdzi się to zbyt dobrze (wykres nie będzie czytelny), odnotujmy, że można też powiązać z wartościami jakiejś zmiennej kolor lub kształt *punktów*:
  

ggplot(pisa) +
  geom_point(aes(x = scorePISAMath,
                 y = scorePISARead,
                 color = schoolType,
                 shape = sex)) 


## Radzenie sobie z nakładającymi się punktami

# Stwórzmy wykres, który będzie obrazował związek pomiędzy wykształceniem rodziców – a dokładnie liczbą lat nauki przypisaną na podstawie poziomu wykształcenia lepiej wykształconego z rodziców – a liczbą osób w gospodarstwie domowym ucznia:
  
ggplot(pisa) +
  geom_point(aes(x = parEdu,
                 y = noPersHous),
             size = 3)

#Z tego wykresu nie da się odczytać użytecznych informacji, bo wykorzystane zmienne są *zbyt mało ciągłe* – choć i jedna, i druga są liczbami, to jednak w praktyce przyjmują tylko niewiele różnych wartości. W konsekwencji przy dużej liczbie obserwacji dla każdej wartości `parEdu` mamy niemal identyczny zestaw występujących wartości liczby członków gospodarstwa domowego. Jednocześnie, ponieważ *punkty* odpowiadające poszczególnym uczniom nakładają się na siebie, nie da się zauważyć, gdzie występują ich *skupiska*, a gdzie tylko pojedyncze obserwacje.

#Aby rozwiązać ten problem, można skorzystać z dwóch innych *geometrii*, które też pozwalają narysować wykres rozrzutu, ale w nieco inny sposób:
  
#  1. `geom_jitter()` dla każdej obserwacji zmienia pozycję *punktu* opisującego daną jednostkę obserwacji o losową wartość – w efekcie punkty, które na zwyczajnym wykresie rozrzutu nakładałyby się na siebie, zostają nieco *rozrzucone* wokół swojej wyjściowej pozycji, co pozwala zauważyć, gdzie jest ich więcej.
#2. `geom_count()` dla każdego miejsca na wykresie, w którym występują obserwacje, zlicza ich liczbę i obrazuje ją poprzez wielkość danego *punktu*.

#(Istnieją jeszcze inne rozwiązania, ale są bardziej skomplikowane, więc nie zostaną tu omówione.)

ggplot(pisa) +
  geom_jitter(aes(x = parEdu,
                  y = noPersHous),
              # parametrami width i height można regulować zakres "rozrzucania"
              width = 0.8,
              height = 0.3)

ggplot(pisa) +
  geom_count(aes(x = parEdu,
                 y = noPersHous))


