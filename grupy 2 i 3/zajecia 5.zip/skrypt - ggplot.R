library(dplyr)
library(readxl)
library(tidyr)
library(janitor)

# Pakiet *ggplot2*

# W R istnieje wiele pakietów umożliwiających tworzenie wykresów m.in.:
  
#+ pakiet *graphics* z podstawowej instalacji R;
#+ pakiet *lattice*, będący odwzorowaniem funkcjonalności bibliotek graficznej *trellis*, dostępnej (komercyjnie) w ramach języka S i S-Plus (czyli tych, których otwartą wersją jest R), który jest używany przede wszystkim do ilustrowania związków w analizach wielozmiennowych;
#+ pakiet *ggplot2*, którego będziemy tu używać;
#+ pakiety *r2d3* i *plotly*, które z poziomu języka R dają dostęp do bibliotek *D3* i *plotly* napisanych w języku Java Script i szeroko wykorzystywanych w tworzeniu aplikacji www.

#Tym, co wyróżnia pakiet *ggplot2*, jest jego interfejs, który został skonstruowany w taki sposób, aby oddzielić od siebie *treść* wykresu od jego *wyglądu*. Dzięki temu możliwe jest bardzo łatwe modyfikowanie tego, jak wykres wygląda (w szczególności zestawu wykorzystywanych kolorów), co zwykle sprawia duży problem w przypadku bardziej *niskopoziomowych* bibliotek graficznych (jak wspomniane wcześniej *graphics*, *D3* czy *plotly*).

#Kolejną zaletą *ggplot2* jest to, że stworzonych zostało wiele dodatkowych pakietów, rozszerzających jego możliwości: patrz [strona z rozszerzeniami ggplot2](https://exts.ggplot2.tidyverse.org/gallery/).

#Bardzo użyteczna w pracy z *ggplot2* będzie też oczywiście oficjalna [strona z dokumentacją pakietu](https://ggplot2.tidyverse.org/).

#Zainstalujmy i załadujmy pakiet *ggplot2*.

if (!("ggplot2" %in% installed.packages()[, 1])) {
  install.packages("ggplot2")}

library(ggplot2)

#W tej części zajęć ponownie posłużymy się zbiorem pisa

pisa <- read_excel("PISA-2009-pogimnazjalne.xlsx", "data")
codebook <- read_excel("PISA-2009-pogimnazjalne.xlsx", "codebook")

# Zaczniemy od wykresów obrazujących liczebność, które robiliśmy w poprzednim ćwiczeniu

pisa %>%
  mutate(scoreTMR_5cat = factor(scoreTMR_5cat,
                                levels = c("very low", "low", "medium",
                                           "high", "very high"))) %>%
  tabyl(scoreTMR_5cat) %>%
  adorn_totals("row") %>%
  adorn_pct_formatting(rounding = "half up", digits = 0) %>%
  knitr::kable()

## Najprostszy wykres liczebności

pisa <- pisa %>%
  mutate(scoreTMR_5cat = factor(scoreTMR_5cat,
                                levels = c("very low", "low", "medium",
                                           "high", "very high")))
ggplot(pisa) +
  geom_bar(aes(x = scoreTMR_5cat))

#Zwróćmy uwagę, że wykorzystane zostały w nim trzy funkcje i operator `+`:
  
#1. Najpierw wywołana zostaje funkcja `ggplot()`.
#- Jako argument przyjmuje ona *ramkę danych*, na podstawie której ma zostać przygotowany wykres.
#2. Następnie operatorem `+` łączy się ją z wywołaniem funkcji, której nazwa rozpoczyna się od przedrostka *geom_* – to, jaka funkcja zostanie tu użyta, decyduje o typie wykresu.
#- Funkcja `geom_bar()` tworzy wykres słupkowy/kolumnowy.
#3. Jako pierwszy argument funkcji, której nazwa rozpoczyna się od przedrostka *geom_*, podaje się wywołanie funkcji `aes()`.
#- Przy pomocy tej funkcji wskazuje się, która kolumna ramki danych ma zostać powiązana z danym elementem wykresu.
#- W kodzie powyżej wskazujemy, że wartości na osi X wykresu powinny zostać utworzone na podstawie kolumny `scoreTMR_5cat`.
#- To, jakie argumenty należy podać, zależy od użytej przez nas funkcji *geom_*.
#lista dostępnych geomów: https://ggplot2.tidyverse.org/reference/
#podstawowoe geomy wraz z wymaganymi własnościami (aesthetics) są wypisane w książce na stronie 124

#- W przypadku `geom_bar()` zawsze trzeba podać albo argument `x` (wtedy uzyskamy wykres kolumnowy), albo argument `y` (wtedy uzyskamy wykres słupkowy – por. kod niżej). Na drugiej osi domyślnie zostanie zaprezentowana liczba obserwacji w ramach wyróżnionych grup.

ggplot(pisa) +
  geom_bar(aes(y = scoreTMR_5cat))

## Zmiana koloru wszystkich *słupków*

#Domyślny szary kolor słupków nie wygląda zbyt atrakcyjnie. Jeśli chcemy zmienić kolor wypełnienia lub obramowania *słupków*, możemy to zrobić, przekazując funkcji `geom_bar()` dodatkowe argumenty: `fill` lub `color`.

#Jako wartości kolorów można podać:
  
#  - nazwę koloru – aby sprawdzić, jakie nazwy rozpoznaje R, można użyć funkcji `colors()` (uwaga: output poniżej jest długi):
 
colors()

#kodu RGB koloru podanego jako ciąg znaków w zapisie szesnastkowym (np. "#000000" to czarny, a "#FF0000" to *sama czerwień*);
# funkcji `rgb()`, `hsv()` aby wygenerować kolory na podstawie różnych parametryzacji przestrzeni barw (odpowiednio: czerwień-zieleń-niebieski i barwa-nasycenie-jasność); przy pomocy argumentu `alpha` można uzyskać efekt przeźroczystości.

#Przykładowo w kodzie poniżej nadajemy *słupkom* półprzeźroczysty kolor czerwony, a ich obramowaniu kolor czarny.

ggplot(pisa) +
  geom_bar(aes(x = scoreTMR_5cat),
           fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5),
           color = "black")

#aesthetics available for bars can be found here:
 # https://ggplot2.tidyverse.org/reference/geom_bar.html#aesthetics

## Podpisy osi i tytuły

#Aby zmienić domyślne podpisy osi, można użyć funkcji `xlab()` i `ylab()`, jak w przykładzie poniżej. Zwróćmy uwagę, że również te funkcje *łączy się* z wcześniejszym kodem generującym wykres przy pomocy operatora `+`.


ggplot(pisa) +
  geom_bar(aes(x = scoreTMR_5cat),
           fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5),
           color = "black") +
  xlab("Wynik Testu Matryc Ravena") +
  ylab("liczba obserwacji")

#Aby dodać tytuł, należy z kolei użyć funkcji `ggtitle()`:

ggplot(pisa) +
  geom_bar(aes(x = scoreTMR_5cat),
           fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5),
           color = "black") +
  xlab("wynik testu matryc Ravena") +
  ylab("liczba obserwacji") +
  ggtitle("Rozkład liczebności","taki raczej prosty")  

  
#Jeśli chcemy zrezygnować z podpisywania danej osi, jako argument wywołania funkcji `xlab()` lub `ylab()` musimy podać `NULL`:

ggplot(pisa) +
  geom_bar(aes(x = scoreTMR_5cat),
           fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5),
           color = "black") +
  xlab(NULL) +
  ylab(NULL) +
  ggtitle("Rozkład liczebności dla testu matryc Ravena")  

# wykres możemy zapisać do oddzielnego obiektu

wykresRaven <- ggplot(pisa) +
  geom_bar(aes(x = scoreTMR_5cat),
           fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5),
           color = "black") +
  xlab(NULL) +
  ylab(NULL) +
  ggtitle("Rozkład liczebności dla testu matryc Ravena")  

#dodawanie kolejnych warstw

wykresRaven +
  geom_hline(yintercept = 800, color = "grey", size = 2)

wykresRaven +
  geom_hline(yintercept = 800, color = "grey", size = 2) +
  annotate("text", x = 5, y = 880, label = "N = 800")

## Skumulowany wykres liczebności

#Jeśli zamiast wykresu, w którym *słupki* odpowiadające poszczególnym kategoriom znajdują się obok siebie, chcielibyśmy uzyskać tzw. wykres skumulowany, w którym *słupki* są odkładane *jeden na drugim* (lub – w przypadku wykresu kolumnowego – *jeden przy drugim*), musimy użyć innych argumentów w wywołaniu funkcji `aes()`: zmienną, która dzieli na grupy, powiązać z kolorem wypełnienia (`fill`), a osi X lub Y (w zależności od tego, czy chcemy otrzymać wykres słupkowy czy kolumnowy) przypisać stałą wartość, np. w formie pustego ciągu znaków:


ggplot(pisa) +
  geom_bar(aes(x = "", fill = scoreTMR_5cat),
          color = "black") +
  xlab(NULL) +
  ylab(NULL) +
  ggtitle("Rozkład liczebności dla testu matryc Ravena")  

wykresRaven2 <- ggplot(pisa) +
  geom_bar(aes(y = "", fill = scoreTMR_5cat),
           color = "black") +
  xlab(NULL) +
  ylab(NULL) +
  ggtitle("Rozkład liczebności dla testu matryc Ravena")  

## Zmiana kolorów opisujących kategorie

#Jeśli kolor wypełnienia (lub obramowania) jest powiązany z wartościami konkretnej zmiennej, to do zmiany zestawu używanych kolorów trzeba wykorzystać inne podejście. Opiera się ono na wywołaniu wybranej funkcji, której nazwa rozpoczyna się od przedrostka *scale_fill_* (a w przypadku koloru obramowania *scale_color_*), np.:
  
#- `scale_fill_hue()` – skale kolorów, które zachowują to samo nasycenie i jasność (to znaczy, że będą właściwie nierozróżnialne wydrukowane w skali szarości!), ale różnią się barwą.
#- domyślny rodzaj skali kolorów wykorzystywany w *ggplot2*
#  - przy pomocy argumentu `h` można ograniczyć zakres wykorzystywanych barw (p. dokumentacja funkcji)
#- argumentami `c` i `l` można podać wartość nasycenia i jasności
#- argument `na.value` można z kolei wykorzystać do zdefiniowania specjalnego koloru, który ma być przypisany brakom danych

wykresRaven2 + scale_fill_hue(l = 20) # trochę ciemniejsze
wykresRaven2 + scale_fill_hue(na.value = "white")

# `scale_fill_brewer()` – pozwala użyć skal kolorów zdefiniowanych na stronie [colorbrewer2.org](https://colorbrewer2.org/#type=sequential&scheme=BuGn&n=3):

#http://applied-r.com/rcolorbrewer-palettes/#:~:text=RColorBrewer%20is%20an%20R%20packages,data%2C%20dark%20for%20high%20data
                               
# aby wybrać konkretną paletę, należy przy pomocy argumentu `palette` podać jeden z następujących ciągów znaków: - "Accent", "Dark2", "Paired", "Pastel1", "Pastel2", "Set1", "Set2", "Set3"

wykresRaven2 + scale_fill_brewer(palette = "Accent")
                                                                     #"BrBG", "PiYG", "PRGn", "PuOr", "RdBu", "RdGy", "RdYlBu", "RdYlGn", "Spectral" (skale charakteryzujące się możliwe dużymi różnicami wykorzystanych kolorów)

wykresRaven2 + scale_fill_brewer(palette = "BrBG")
                                               
#- "Blues", "BuGn", "BuPu", "GnBu", "Greens", "Greys", "Oranges", "OrRd", "PuBu", "PuBuGn", "PuRd", "Purples", "RdPu", "Reds", "YlGn", "YlGnBu", "YlOrBr", "YlOrRd" (skale, w których wykorzystane kolory zmieniają się stopniowo)    

wykresRaven2 + scale_fill_brewer(palette = "Blues", na.value = "grey") 

- #`scale_fill_viridis_d()` – pozwala użyć skal, które są przyjazne osobom z zaburzeniami widzenia kolorów (tzn. kolory wykorzystywane w ramach takich skal różnią się także jasnością):
#- kolory użyte w tych skalach **dają się łatwo rozróżnić przy drukowaniu wykresów w odcieniach szarości**
#- dostępnych jest 5 skal, które można wybrać, podając argumentem `option` jeden z ciągów znaków: "magma", "inferno", "plasma", "viridis" (domyślna opcja), "cividis"

wykresRaven2 + scale_fill_viridis_d(option = "viridis")
wykresRaven2 + scale_fill_viridis_d(option = "magma")
                                                                    #`scale_fill_manual()` – pozwala samodzielnie zdefiniować użyte kolory:                                                              # argumentem `values` podaje się wektor, którego elementy opisują kolory (na jeden ze sposobów wymienionych w sekcji *Zmiana koloru wszystkich słupków*); ten wektor nie może być krótszy niż liczba grup 
wykresRaven2 + scale_fill_manual(values = c('#fef0d9','#fdcc8a','#fc8d59','#e34a33','#b30000'), na.value = "grey")

## Etykieta zmiennej opisującej kolor kategorii

#Kiedy przypisaliśmy jakąś zmienną do koloru wypełnienia, na wykresie pojawiła się legenda. Jeśli chcesz, aby powyżej pól z kolorami i nazwami kategorii zamiast nazwy tej zmiennej pojawił się inny tekst, możesz podać go jako pierwszy argument funkcji `scale_fill_[...]()`:
                                                                     
wykresRaven2 + scale_fill_manual("wynik testu", values = c('#fef0d9','#fdcc8a','#fc8d59','#e34a33','#b30000'), na.value = "grey")

# Wykresy obrazujące częstość
                                                              #Przejdźmy do wykresów, które pozwalają zwizualizować rozkłady częstości, a więc takich, które są zwykle bardziej użyteczne do opisywania związków pomiędzy zmiennymi.

## Skumulowany rozkład słupkowy/kolumnowy częstości
#Aby zmienić wykres obrazujący liczebność na wykres obrazujący częstość, do wywołania funkcji `geom_bar()` należy dodać argument `position = "fill"`:
                                                                    
# wykres częstości
ggplot(pisa) +
  geom_bar(aes(y = "", fill = scoreTMR_5cat), position = "fill", color = "black") +
  xlab(NULL) +  
  ylab(NULL) + 
  ggtitle("Rozkład częstości dla testu matryc Ravena")                                                                 
#Argument ten wskazuje, że w ramach każdej grupy (wyróżnionej ze względu na wartość zmiennej przypisanej do osi X lub do osi Y) suma wysokości (lub szerokości) *słupków* ma sumować się do 1.
                                                                     
#dla "zwykłego" rozkładu
wykresRaven + scale_y_continuous(labels = scales::percent_format(scale = 100/nrow(pisa)))                                                                   
#możemy też rysować bezpośrednio z tabeli z rozkładem:
rlicz <- pisa %>% tabyl(scoreTMR_5cat)

ggplot(rlicz) + 
  geom_bar(aes(x = scoreTMR_5cat),
    fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black")

ggplot(rlicz) + 
  geom_bar(aes(x = scoreTMR_5cat, y = n), stat = "identity",
  fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black") 

ggplot(rlicz) + 
  geom_bar(aes(x = scoreTMR_5cat, y = percent), stat = "identity",
           fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black") 

rlicz %>% ggplot(aes(x = scoreTMR_5cat, y = percent)) + 
  geom_bar(stat = "identity", fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black")  


## Etykiety wartości na wykresie

# Jeśli wykres jest rysowany z przygotowanej wcześniej tabeli z rozkładem, możliwe jest łatwe dodanie do niego etykiet wartości przy pomocy funkcji `geom_label()`. Wywołanie tej funkcji dodajemy do istniejącego wykresu używając operatora `+`. Podobnie jak wcześniej w przypadku `geom_bar()`, pierwszym argumentem funkcji `geom_label()` będzie wywołanie funkcji `aes()` – w przypadku tej *geometrii* należy podać argumenty `x` i `y` (w ten sam sposób, co w wywołaniu w ramach `geom_bar()`), `group` (tu należy podać zmienną, która w ramach `geom_bar()` została powiązana z kolorem wypełnienia) oraz `label` (ten argument wskazuje, skąd ma zostać wzięta treść etykiety wartości). Dodatkowo, analogicznie jak w wywołaniu `geom_bar()`, należy też użyć (już poza funkcją `aes()`!) argumentów `stat = "identity"` i `position = "fill"`, pozostawiając tylko niezbędne elementy z kodu tworzącego wykres z poprzedniej sekcji:
  
rlicz %>% ggplot(aes(x = scoreTMR_5cat, y = percent)) + 
  geom_bar(stat = "identity", fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black") +
  geom_label(aes(label=round(percent,2)))

#Możemy chcieć upiększyć te etykiety, stosując funkcję `percent()` przy definiowaniu przypisania dla argumentu `label` w ramach wywołana `aes()` (uwaga: to nie ta sama funkcja, co `percent_format()`, której używamy, aby zamienić na procenty etykiety osi Y):

library(scales) #tu jest funkcja formatująca skalę label_percent

rlicz %>% ggplot(aes(x = scoreTMR_5cat, y = percent)) + 
  geom_bar(stat = "identity", fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black") +
  geom_label(aes(label=percent(percent))) +
  scale_y_continuous(labels = label_percent())
  
#Wielkość czcionki, jaką wyświetlane są etykiety, można zmieniać argumentem `size` (na wykresie poniżej są one mniejsze):
  
rlicz %>% ggplot(aes(x = scoreTMR_5cat, y = percent)) + 
  geom_bar(stat = "identity", fill = rgb(red = 1, green = 0, blue = 0, alpha = 0.5), color = "black") +
  geom_label(aes(label=percent(percent)), size = 3) +
  scale_y_continuous(labels = label_percent())

## Zmiana ogólnego wyglądu wykresu

#Ogólny wygląd wykresu można zmieniać przy pomocy funkcji, których nazwy rozpoczynają się od *theme_*. W pakiecie *ggplot2* mamy do wyboru kilka schematów:
  
#- `theme_gray()` – domyślny
#- `theme_dark()` – nazwa mówi sama za siebie
#- `theme_bw()`, `theme_linedraw()`, `theme_light()`, `theme_minimal()`, `theme_classic()` – białe tło wykresu, różnią się sposobem rysowania obramowania wykresu i linii siatki

wykres <- rlicz %>% ggplot(aes(x = scoreTMR_5cat, y = percent)) + 
  geom_bar(stat = "identity") +
  geom_label(aes(label=percent(percent)), size = 3) +
  scale_y_continuous(labels = label_percent())

wykres
wykres + theme_dark()
wykres + theme_bw()
wykres + theme_classic()
wykres + theme_minimal()
wykres + theme_light()

#Można też samodzielnie zmieniać wybrane elementy *tematu*, korzystając z funkcji `theme()`.

